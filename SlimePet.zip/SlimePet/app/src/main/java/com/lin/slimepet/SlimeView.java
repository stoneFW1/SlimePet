package com.lin.slimepet;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.Random;

/**
 * 元素史莱姆：圆顶果冻身体 + 发光眼 + 七种元素（草/风/雷有头顶装饰）。
 * 视觉与网页预览 slime2.html 一致。
 */
public class SlimeView extends View {

    public interface Callback {
        void onTap();
        void onDoubleTap();
        void onLongPress();
        void onDrag(float dx, float dy);
        void onDragEnd(float vx, float vy);
        void onElementChanged(String name);
    }

    /* ---------- 元素配色 ---------- */
    private static final int[] DEEP  = {0xFF8A1C07, 0xFF0E6B74, 0xFF4A1580, 0xFF5E4A22, 0xFF2B6A1C, 0xFF1F5F8A, 0xFF123F75};
    private static final int[] MID   = {0xFFF2620F, 0xFF37C6C0, 0xFF9B45E0, 0xFFC9A05A, 0xFF77C13A, 0xFF63C3EA, 0xFF2F8FD6};
    private static final int[] LIGHT = {0xFFFFC24A, 0xFFB9FDF6, 0xFFE6C4FF, 0xFFF4E3B8, 0xFFCDF59A, 0xFFDCF6FF, 0xFFBFEAFF};
    private static final int[] AURA  = {0xFFFF5A1E, 0xFF2FF0D8, 0xFFB56BFF, 0xFFE8B45C, 0xFF8DE83C, 0xFF7FE3FF, 0xFF3FB6FF};
    private static final int[] EYE   = {0xFFFFE08A, 0xFFEAFFFB, 0xFFFDF3FF, 0xFFFFCF7A, 0xFFFFE9A3, 0xFFF4FEFF, 0xFFEAFAFF};
    private static final int[] CORE  = {0xFFFF6A2A, 0xFF8FE8E0, 0xFFC98BFF, 0xFFFF9A3C, 0xFFFFB038, 0xFFA8E8FF, 0xFF66C8FF};
    private static final String[] NAME = {"火", "风", "雷", "岩", "草", "冰", "水"};
    private static final String[] KEY  = {"fire", "anemo", "electro", "geo", "grass", "cryo", "water"};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path body = new Path();
    private final RectF oval = new RectF();
    private final Random rnd = new Random();

    private int idx = 4;                 /* 默认草 */
    private float squash = 0f, squashV = 0f;
    private float blush = 0f;
    private int clip = -1;
    private long clipStart = 0L;
    private float clipDur = 1f;
    private long nextClip = 0L;
    private float gazeX = 0f, gazeY = 0f;
    private boolean sleeping = false;
    private long sleepAt = 0L, lastAct = 0L;
    private float blink = 1f;
    private long nextBlink = 0L, blinkUntil = 0L, nextGlance = 0L;

    private long lastFrame = 0L;
    private float time = 0f;
    private int pose = 0;            /* 0 地面 1 左壁 2 右壁 3 天花板 */
    private float wallFlat = 0f;     /* 贴墙时压扁的程度 0~1 */
    private float idlePulse = 0f;
    private float glanceTo = 0f;
    private long glanceUntil = 0L;

    private final int slop;
    private float downRawX, downRawY, lastRawX, lastRawY;
    private boolean down = false, dragging = false, longFired = false;
    private long lastTap = 0L;
    private float dragVx = 0f, dragVy = 0f;

    private Callback cb;

    private final Runnable longJob = new Runnable() {
        @Override public void run() {
            if (down && !dragging) {
                longFired = true;
                if (cb != null) cb.onLongPress();
            }
        }
    };

    public SlimeView(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        try {
            SharedPreferences sp = c.getSharedPreferences("slimepet", Context.MODE_PRIVATE);
            String saved = sp.getString("element_key", "");
            int found = -1;
            for (int i = 0; i < KEY.length; i++) if (KEY[i].equals(saved)) { found = i; break; }
            idx = found >= 0 ? found : rnd.nextInt(KEY.length);
        } catch (Exception ignored) {}
        long now = SystemClock.uptimeMillis();
        lastAct = now; lastFrame = now;
        nextBlink = now + 2600L;
    }

    public void setCallback(Callback c) { cb = c; }
    public void poke() { squashV += 3.0f; blush = 1f; waking(); playClip(0); }
    public int elementIndex() { return idx; }
    public String elementKey() { return KEY[idx]; }
    public String elementName() { return NAME[idx]; }

    public void setElementIndex(int i) {
        idx = ((i % KEY.length) + KEY.length) % KEY.length;
        squashV += 1.4f;
        try {
            getContext().getSharedPreferences("slimepet", Context.MODE_PRIVATE)
                    .edit().putString("element_key", KEY[idx]).apply();
        } catch (Exception ignored) {}
        if (cb != null) cb.onElementChanged(NAME[idx]);
        invalidate();
    }

    public void setGaze(float nx, float ny) { gazeX = nx; gazeY = ny; }

    /** 0 地面 / 1 左壁 / 2 右壁 / 3 天花板：换个姿势贴上去 */
    public void setPose(int p) { pose = p; }

    /** 起跳前把身体拉长一点 */
    public void hopStart() { squashV -= 2.4f; }

    /** 落地：压扁 + 泛红 */
    public void land() { squashV += 3.2f; blush = Math.max(blush, 0.55f); }
    public void setSleeping(boolean s) {
        sleeping = s;
        if (s) sleepAt = SystemClock.uptimeMillis();
        else waking();
        invalidate();
    }
    public boolean isSleeping() { return sleeping; }

    /* 每个关键帧：进度, 横向缩放, 纵向缩放, 旋转角度, 横向位移(×R), 纵向位移(×R) */
    private static final float[][][] CLIPS = {
        /* 0 弹一下 */
        {{0f,1f,1f,0f,0f,0f},{0.16f,0.86f,1.18f,0f,0f,0f},{0.34f,1.12f,0.88f,0f,0f,0f},
         {0.55f,0.95f,1.06f,0f,0f,0f},{0.78f,1.03f,0.98f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 1 伸个懒腰 */
        {{0f,1f,1f,0f,0f,0f},{0.30f,0.92f,1.22f,0f,0f,-0.06f},{0.55f,0.92f,1.24f,0f,0f,-0.07f},
         {0.75f,1.08f,0.94f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 2 歪头看看左边、再看看右边 */
        {{0f,1f,1f,0f,0f,0f},{0.22f,0.97f,1.03f,-9f,-0.05f,0f},{0.45f,0.97f,1.03f,-9f,-0.05f,0f},
         {0.68f,0.97f,1.03f,9f,0.05f,0f},{0.85f,0.99f,1.01f,4f,0.02f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 3 原地滚一圈 */
        {{0f,1f,1f,0f,0f,0f},{0.2f,1.04f,0.96f,-25f,0f,0f},{0.45f,1.02f,0.98f,-180f,0f,-0.04f},
         {0.7f,1.02f,0.98f,-300f,0f,0f},{0.9f,0.94f,1.08f,-360f,0f,0f},{1f,1f,1f,-360f,0f,0f}},
        /* 4 果冻晃：先猛压再一层层回 */
        {{0f,1f,1f,0f,0f,0f},{0.14f,1.16f,0.80f,0f,0f,0.02f},{0.32f,0.86f,1.16f,0f,0f,0f},
         {0.5f,1.10f,0.92f,0f,0f,0f},{0.68f,0.94f,1.05f,0f,0f,0f},{0.85f,1.03f,0.98f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 5 轻轻跳一下 */
        {{0f,1f,1f,0f,0f,0f},{0.12f,0.9f,1.14f,0f,0f,0.02f},{0.35f,0.95f,1.1f,0f,0f,-0.20f},
         {0.55f,1.02f,1f,0f,0f,-0.26f},{0.75f,1.14f,0.86f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 6 跳舞：左右扭 */
        {{0f,1f,1f,0f,0f,0f},{0.15f,0.95f,1.06f,-8f,-0.08f,0f},{0.32f,1.04f,0.96f,8f,0.08f,0f},
         {0.50f,0.95f,1.06f,-8f,-0.08f,0f},{0.68f,1.04f,0.96f,8f,0.08f,0f},
         {0.84f,0.98f,1.03f,-4f,-0.03f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 7 打哈欠：先扁后长 */
        {{0f,1f,1f,0f,0f,0f},{0.25f,0.90f,1.24f,0f,0f,-0.04f},{0.55f,0.86f,1.30f,0f,0f,-0.05f},
         {0.78f,1.06f,0.96f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 8 抖一抖（快频小抖） */
        {{0f,1f,1f,0f,0f,0f},{0.10f,1.02f,0.99f,-3f,-0.03f,0f},{0.20f,1.02f,0.99f,3f,0.03f,0f},
         {0.30f,1.02f,0.99f,-3f,-0.03f,0f},{0.40f,1.02f,0.99f,3f,0.03f,0f},
         {0.50f,1.02f,0.99f,-2f,-0.02f,0f},{0.60f,1.02f,0.99f,2f,0.02f,0f},
         {0.75f,1.01f,1f,-1f,-0.01f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 9 被吓一跳：猛缩一下再慢慢鼓回来 */
        {{0f,1f,1f,0f,0f,0f},{0.10f,0.72f,1.22f,0f,0f,0.05f},{0.28f,0.80f,1.14f,0f,0f,0.03f},
         {0.50f,1.06f,0.95f,0f,0f,0f},{0.72f,0.97f,1.03f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 10 点头两下 */
        {{0f,1f,1f,0f,0f,0f},{0.16f,1.03f,0.96f,0f,0f,0.05f},{0.30f,0.98f,1.02f,0f,0f,0f},
         {0.46f,1.03f,0.96f,0f,0f,0.05f},{0.62f,0.98f,1.02f,0f,0f,0f},{1f,1f,1f,0f,0f,0f}},
        /* 11 半圈侧翻再翻回来 */
        {{0f,1f,1f,0f,0f,0f},{0.18f,1.02f,0.97f,60f,0f,-0.05f},{0.40f,1.05f,0.95f,180f,0f,-0.10f},
         {0.62f,1.02f,0.98f,290f,0f,-0.05f},{0.82f,0.96f,1.06f,360f,0f,0f},{1f,1f,1f,360f,0f,0f}},
    };
    private static final float[] CLIP_DUR = {0.9f, 1.6f, 1.0f, 1.5f, 0.9f, 0.9f, 1.4f, 1.5f, 1.0f, 0.9f, 1.1f, 1.5f};

    private void playClip(int i) {
        clip = i;
        clipStart = SystemClock.uptimeMillis();
        clipDur = i < CLIP_DUR.length ? CLIP_DUR[i] : 1f;
    }

    public void playRandomClip() {
        playClip(rnd.nextInt(CLIPS.length));
    }

    private void waking() {
        sleeping = false;
        lastAct = SystemClock.uptimeMillis();
    }

    /** 随机往左或右瞄一眼 */
    public void glance() {
        glanceTo = (rnd.nextFloat() < 0.5f ? -1f : 1f);
        glanceUntil = SystemClock.uptimeMillis() + 900L;
    }

    /* ---------------- 触摸 ---------------- */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float rx = e.getRawX(), ry = e.getRawY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                down = true; dragging = false; longFired = false;
                downRawX = lastRawX = rx;
                downRawY = lastRawY = ry;
                dragVx = dragVy = 0f;
                waking();
                removeCallbacks(longJob);
                postDelayed(longJob, 600L);
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = rx - lastRawX, dy = ry - lastRawY;
                lastRawX = rx; lastRawY = ry;
                if (!dragging && (Math.abs(rx - downRawX) + Math.abs(ry - downRawY)) > slop) {
                    dragging = true;
                    removeCallbacks(longJob);
                }
                if (dragging) {
                    dragVx = dragVx * 0.6f + dx * 0.4f;
                    dragVy = dragVy * 0.6f + dy * 0.4f;
                    if (cb != null) cb.onDrag(dx, dy);
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                down = false;
                removeCallbacks(longJob);
                if (dragging) {
                    dragging = false;
                    if (cb != null) cb.onDragEnd(dragVx, dragVy);
                    return true;
                }
                if (longFired) return true;
                long now = SystemClock.uptimeMillis();
                if (now - lastTap < 260L) {
                    lastTap = 0L;
                    if (cb != null) cb.onDoubleTap();
                } else {
                    lastTap = now;
                    if (cb != null) cb.onTap();
                }
                return true;
            }
        }
        return super.onTouchEvent(e);
    }

    /* ---------------- 绘制 ---------------- */
    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
        if (dt < 0f) dt = 0f;
        lastFrame = now;
        time += dt;

        /* 弹簧：被戳后先陷后弹 */
        squashV += (-squash * 58f - squashV * 7.2f) * dt;
        squash += squashV * dt;
        if (blush > 0f) blush = Math.max(0f, blush - dt * 0.5f);

        /* 眨眼 */
        if (now > nextBlink) { blinkUntil = now + 110L; nextBlink = now + 2800L + rnd.nextInt(3600); }
        blink = now < blinkUntil ? 0.12f : Math.min(1f, blink + dt * 9f);

        /* 自己犯困 */
        if (!sleeping && now - lastAct > 90000L) setSleeping(true);

        /* 张望：一段时间就瞄一眼 */
        if (now < glanceUntil) {
            gazeX = glanceTo;
        } else {
            if (gazeX != 0f) gazeX = 0f;
            if (now > nextGlance) { nextGlance = now + 3500L + rnd.nextInt(6000); glance(); }
        }

        float w = getWidth(), h = getHeight();
        float R = Math.min(w, h) * 0.33f;
        float cx = w * 0.5f, cy = h * 0.60f;

        c.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR);

        /* 基础呼吸 + 轻微摇摆 */
        float sway = (float) Math.sin(time * 1.15f) * 2.2f;
        float swayX = (float) Math.sin(time * 0.85f) * R * 0.03f;
        float breathe = 1f + (float) Math.sin(time * 1.6f) * 0.016f;
        float sx = breathe, sy = 2f - breathe, rot = sway, dx = swayX, dy = 0f;

        /* 关键帧动画叠加 */
        if (clip >= 0) {
            long el = now - clipStart;
            float pr = el / (clipDur * 1000f);
            if (pr >= 1f) { clip = -1; }
            else {
                float[][] fr = CLIPS[clip];
                int k = 0;
                while (k < fr.length - 2 && fr[k + 1][0] < pr) k++;
                float t0 = fr[k][0], t1 = fr[k + 1][0];
                float u = t1 <= t0 ? 0f : (pr - t0) / (t1 - t0);
                sx *= lerp(fr[k][1], fr[k + 1][1], u);
                sy *= lerp(fr[k][2], fr[k + 1][2], u);
                rot += lerp(fr[k][3], fr[k + 1][3], u);
                dx += lerp(fr[k][4], fr[k + 1][4], u) * R;
                dy += lerp(fr[k][5], fr[k + 1][5], u) * R;
            }
        } else if (!sleeping && now > nextClip) {
            playClip(rnd.nextInt(CLIPS.length));
            nextClip = now + 2200L + rnd.nextInt(3800);
        }

        c.save();
        c.translate(cx + dx, cy + dy);
        c.rotate(rot);
        c.scale(sx, sy);
        c.translate(-cx, -cy);

        /* 贴墙：把整只画旋转过去，看起来就是趴在墙上 */
        float targetFlat = pose == 0 ? 0f : (pose == 3 ? 0.55f : 0.85f);
        wallFlat += (targetFlat - wallFlat) * Math.min(1f, dt * 6f);
        c.save();
        /* 贴边：按"压扁之后肚子最外沿的位置"实时算，永远正好贴住屏幕边 */
        float flatY = 0.60f * R * (1f - wallFlat * 0.14f);   /* 天花板：y 轴压扁 */
        float flatS = 0.60f * R * (1f - wallFlat * 0.12f);   /* 侧壁：x 轴压扁，转到屏幕 y 上 */
        if (pose == 1) c.translate(-(w * 0.5f - flatS), 0f);
        else if (pose == 2) c.translate(w * 0.5f - flatS, 0f);
        else if (pose == 3) c.translate(0f, -(cy - flatY));

        /* 贴壁：屁股（平底）对着墙，脑袋朝屏幕中间；天花板：倒挂 */
        if (pose == 1) c.rotate(90f, cx, cy);        /* 左壁：底朝左 */
        else if (pose == 2) c.rotate(-90f, cx, cy);  /* 右壁：底朝右 */
        else if (pose == 3) c.rotate(180f, cx, cy);  /* 天花板：底朝上 */
        if (wallFlat > 0.01f) {
            if (pose == 3) c.scale(1f + wallFlat * 0.08f, 1f - wallFlat * 0.14f, cx, cy);
            else c.scale(1f - wallFlat * 0.12f, 1f + wallFlat * 0.06f, cx, cy);
        }
        drawSlime(c, cx, cy, R, idx, time, dt);
        if (sleeping) drawZzz(c, cx + R * 0.7f, cy - R * 0.9f);
        c.restore();
        c.restore();

        postInvalidateOnAnimation();
    }

    private void drawSlime(Canvas c, float cx, float cy, float R, int i, float t, float dt) {
        int deep = DEEP[i], mid = MID[i], light = LIGHT[i], aura = AURA[i];

        /* 1. 外圈光晕 */
        fill.setShader(new RadialGradient(cx, cy + R * 0.06f, R * 1.75f,
                new int[]{withAlpha(aura, 0.26f), withAlpha(aura, 0.08f), withAlpha(aura, 0f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy + R * 0.06f, R * 1.75f, fill);
        fill.setShader(null);

        /* 2. 身体路径 */
        buildBody(cx, cy, R);
        c.save();
        c.clipPath(body);

        fill.setShader(new LinearGradient(cx, cy - R * 0.92f, cx, cy + R * 0.60f,
                new int[]{withAlpha(mid, 0.95f), withAlpha(mid, 0.88f), withAlpha(light, 0.74f), withAlpha(light, 0.62f)},
                new float[]{0f, 0.40f, 0.76f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(cx - R * 2, cy - R * 2, cx + R * 2, cy + R * 2, fill);
        fill.setShader(null);

        /* 内部亮核 */
        fill.setShader(new RadialGradient(cx, cy + R * 0.24f, R * 0.92f,
                new int[]{withAlpha(light, 0.40f), withAlpha(light, 0f)},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(cx - R * 2, cy - R * 2, cx + R * 2, cy + R * 2, fill);
        fill.setShader(null);

        drawTexture(c, cx, cy, R, i, t);

        /* 左上高光 */
        c.save();
        c.rotate(-35f, cx - R * 0.34f, cy - R * 0.46f);
        oval.set(cx - R * 0.64f, cy - R * 0.56f, cx - R * 0.04f, cy - R * 0.36f);
        fill.setShader(new LinearGradient(0f, cy - R * 0.56f, 0f, cy - R * 0.36f,
                new int[]{0x9EFFFFFF, 0x00FFFFFF}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        c.drawOval(oval, fill);
        fill.setShader(null);
        c.restore();

        /* 腮红 */
        if (blush > 0.01f) {
            for (int s = -1; s <= 1; s += 2) {
                float bx = cx + s * R * 0.56f, by = cy + R * 0.16f;
                fill.setShader(new RadialGradient(bx, by, R * 0.26f,
                        new int[]{withAlpha(0xFFFF6E96, 0.45f * blush), withAlpha(0xFFFF6E96, 0f)},
                        new float[]{0f, 1f}, Shader.TileMode.CLAMP));
                c.drawCircle(bx, by, R * 0.26f, fill);
                fill.setShader(null);
            }
        }
        c.restore();

        /* 3. 边缘透光 */
        c.save();
        c.clipPath(body);
        line.setStyle(Paint.Style.STROKE);
        line.setShader(null);
        line.setColor(withAlpha(light, 0.32f));
        line.setStrokeWidth(Math.max(3f, R * 0.15f));
        c.drawPath(body, line);
        line.setColor(0x33FFFFFF);
        line.setStrokeWidth(Math.max(1.2f, R * 0.022f));
        c.drawPath(body, line);
        c.restore();

        /* 4. 头顶装饰（只有草 / 风 / 雷） */
        drawCrown(c, cx, cy, R, i, t);

        /* 5. 发光眼 */
        drawEyes(c, cx, cy, R, i, t);
    }

    private void buildBody(float cx, float cy, float R) {
        body.reset();
        final int N = 120;
        final float tw = time * 1.5f;
        final float h2 = 0.014f + (float) Math.sin(time * 2.1f) * 0.006f;
        final float sq = squash * 0.10f + (float) Math.sin(time * 1.4f) * 0.03f;
        for (int k = 0; k <= N; k++) {
            double th = k * 2.0 * Math.PI / N;
            double sn = Math.sin(th), cs = Math.cos(th);
            boolean top = sn < 0;
            float w1 = (float) (Math.sin(th * 2 + tw) * h2 + Math.sin(th * 3 - tw * 0.6) * 0.006);
            float squashF = 1f + sq * (top ? -0.55f : 0.85f);
            float ry = (top ? 0.98f : 0.60f) * squashF;
            float flatPow = top ? 1.0f : 0.80f;
            float taper = top ? 1f - 0.10f * (float) Math.pow(Math.abs(sn), 2.2) : 1f;
            float spread = top ? 1f : 1f + 0.06f * (float) Math.pow(Math.abs(sn), 0.45);
            float rx = 0.94f * taper * spread * (1f + w1);
            float x = cx + (float) cs * R * rx;
            float y = cy + (sn >= 0 ? 1f : -1f) * (float) Math.pow(Math.abs(sn), flatPow) * R * ry * (1f + w1 * 0.5f);
            if (k == 0) body.moveTo(x, y); else body.lineTo(x, y);
        }
        body.close();
    }

    private void drawTexture(Canvas c, float cx, float cy, float R, int i, float t) {
        String key = KEY[i];
        if ("fire".equals(key)) {
            for (int k = 0; k < 4; k++) {
                float bx = cx + (k - 1.5f) * R * 0.26f + (float) Math.sin(t * 0.5f) * R * 0.06f;
                float by = cy + R * (0.16f + (k % 2) * 0.22f);
                fill.setShader(new RadialGradient(bx, by, R * 0.28f,
                        new int[]{0x57FFECA0, 0x33FF7C2A, 0x00B41E00},
                        new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
                c.drawCircle(bx, by, R * 0.28f, fill);
                fill.setShader(null);
            }
        } else if ("grass".equals(key)) {
            fill.setShader(null);
            fill.setColor(withAlpha(0xFF2B6A1C, 0.22f));
            for (int k = 0; k < 8; k++) {
                double a = k * 2.1;
                float bx = cx + (float) Math.cos(a) * R * 0.46f;
                float by = cy + (float) Math.sin(a) * R * 0.28f + R * 0.08f;
                oval.set(bx - R * 0.055f, by - R * 0.038f, bx + R * 0.055f, by + R * 0.038f);
                c.drawOval(oval, fill);
            }
            fill.setColor(0x8CFFE878);
            for (int k = 0; k < 3; k++) {
                c.drawCircle(cx + (k - 1) * R * 0.30f, cy + R * 0.34f, R * 0.018f, fill);
            }
        } else if ("electro".equals(key)) {
            line.setShader(null);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(0x4DFFFFFF);
            line.setStrokeWidth(R * 0.020f);
            line.setStrokeCap(Paint.Cap.ROUND);
            for (int s = -1; s <= 1; s += 2) {
                Path p2 = new Path();
                p2.moveTo(cx + s * R * 0.40f, cy + R * 0.10f);
                p2.lineTo(cx + s * R * 0.52f, cy + R * 0.26f);
                p2.lineTo(cx + s * R * 0.44f, cy + R * 0.26f);
                c.drawPath(p2, line);
            }
        } else if ("cryo".equals(key)) {
            line.setShader(null);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(0x47FFFFFF);
            line.setStrokeWidth(R * 0.015f);
            for (int k = 0; k < 3; k++) {
                float bx = cx - R * 0.36f + k * R * 0.36f, by = cy + R * 0.30f;
                for (int m = 0; m < 3; m++) {
                    double a = m * Math.PI / 3.0;
                    Path p2 = new Path();
                    p2.moveTo(bx - (float) Math.cos(a) * R * 0.06f, by - (float) Math.sin(a) * R * 0.06f);
                    p2.lineTo(bx + (float) Math.cos(a) * R * 0.06f, by + (float) Math.sin(a) * R * 0.06f);
                    c.drawPath(p2, line);
                }
            }
        } else if ("anemo".equals(key)) {
            line.setShader(null);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(0x47FFFFFF);
            line.setStrokeWidth(R * 0.020f);
            line.setStrokeCap(Paint.Cap.ROUND);
            for (int s = -1; s <= 1; s += 2) {
                RectF r2 = new RectF(cx + s * R * 0.30f - R * 0.17f, cy + R * 0.22f - R * 0.17f,
                        cx + s * R * 0.30f + R * 0.17f, cy + R * 0.22f + R * 0.17f);
                c.drawArc(r2, s > 0 ? 86f : -86f, 140f, false, line);
            }
        } else if ("geo".equals(key)) {
            line.setShader(null);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(0x38786034);
            line.setStrokeWidth(R * 0.014f);
            Path p2 = new Path();
            p2.moveTo(cx - R * 0.44f, cy + R * 0.36f); p2.lineTo(cx - R * 0.26f, cy + R * 0.44f);
            p2.moveTo(cx + R * 0.28f, cy + R * 0.38f); p2.lineTo(cx + R * 0.44f, cy + R * 0.30f);
            p2.moveTo(cx - R * 0.06f, cy + R * 0.44f); p2.lineTo(cx + R * 0.04f, cy + R * 0.36f);
            c.drawPath(p2, line);
        } else {
            line.setShader(null);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(0x33FFFFFF);
            line.setStrokeWidth(R * 0.018f);
            line.setStrokeCap(Paint.Cap.ROUND);
            for (int s = -1; s <= 1; s += 2) {
                Path p2 = new Path();
                p2.moveTo(cx + s * R * 0.18f, cy + R * 0.42f);
                p2.quadTo(cx + s * R * 0.42f, cy + R * 0.30f, cx + s * R * 0.60f, cy + R * 0.42f);
                c.drawPath(p2, line);
            }
            line.setStrokeWidth(R * 0.011f);
            line.setColor(0x57FFFFFF);
            for (int k = 0; k < 4; k++) {
                double ph = t * 0.6 + k * 1.9;
                float bx = cx + (float) Math.cos(ph) * R * 0.34f;
                float by = cy + (float) Math.sin(ph * 1.4) * R * 0.20f + R * 0.14f;
                c.drawCircle(bx, by, R * (0.042f + k * 0.008f), line);
            }
        }
    }

    private void drawCrown(Canvas c, float cx, float cy, float R, int i, float t) {
        String key = KEY[i];
        float topY = cy - R * 0.90f;
        float bob = (float) Math.sin(t * 1.3f) * R * 0.012f;

        if ("grass".equals(key)) {
            c.save();
            c.translate(cx + R * 0.02f, topY + R * 0.40f + bob);
            c.rotate(-19f + (float) Math.sin(t) * 3f);
            c.scale(0.82f, 0.82f);
            Path leaf = new Path();
            leaf.moveTo(0, R * 0.16f);
            leaf.cubicTo(-R * 0.14f, R * 0.02f, -R * 0.20f, -R * 0.24f, -R * 0.06f, -R * 0.50f);
            leaf.cubicTo(R * 0.16f, -R * 0.36f, R * 0.26f, -R * 0.06f, 0, R * 0.16f);
            fill.setShader(new LinearGradient(0, -R * 0.50f, 0, R * 0.16f,
                    new int[]{0xF5A8E86E, 0xF0387C1C}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            c.drawPath(leaf, fill);
            fill.setShader(null);
            line.setShader(null); line.setStyle(Paint.Style.STROKE);
            line.setColor(0x66E8FFC4); line.setStrokeWidth(R * 0.012f);
            c.drawPath(leaf, line);
            c.restore();
            /* 小花 */
            c.save();
            c.translate(cx - R * 0.26f, topY + R * 0.30f + bob);
            for (int k = 0; k < 5; k++) {
                c.save();
                c.rotate(k * 72f);
                fill.setShader(null);
                fill.setColor(0xF5FFFAE0);
                oval.set(-R * 0.046f, -R * 0.106f, R * 0.046f, -R * 0.014f);
                c.drawOval(oval, fill);
                c.restore();
            }
            fill.setColor(0xFFFFD76A);
            c.drawCircle(0, 0, R * 0.040f, fill);
            c.restore();

        } else if ("anemo".equals(key)) {
            for (int s = -1; s <= 1; s += 2) {
                c.save();
                c.translate(cx + s * R * 0.36f, topY + R * 0.36f);
                c.rotate(s * -15f);
                Path horn = new Path();
                horn.moveTo(0, R * 0.16f);
                horn.cubicTo(s * R * 0.16f, -R * 0.14f, s * R * 0.26f, -R * 0.30f, s * R * 0.28f, -R * 0.50f);
                horn.cubicTo(s * R * 0.44f, -R * 0.26f, s * R * 0.26f, 0, 0, R * 0.16f);
                fill.setShader(new LinearGradient(0, -R * 0.50f, 0, R * 0.16f,
                        new int[]{0xFAFFFFFF, 0xEBE2FFFC, 0xB396E6E1}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
                c.drawPath(horn, fill);
                fill.setShader(null);
                c.restore();
            }
            line.setShader(null); line.setStyle(Paint.Style.STROKE);
            line.setColor(0x80FFFFFF); line.setStrokeWidth(R * 0.035f);
            line.setStrokeCap(Paint.Cap.ROUND);
            for (int s = -1; s <= 1; s += 2) {
                RectF r2 = new RectF(cx + s * R * 0.58f - R * 0.13f, cy + R * 0.06f - R * 0.13f,
                        cx + s * R * 0.58f + R * 0.13f, cy + R * 0.06f + R * 0.13f);
                c.drawArc(r2, s > 0 ? 31f : 138f, 110f, false, line);
            }

        } else if ("electro".equals(key)) {
            c.save();
            c.translate(cx, topY + R * 0.32f + bob);
            line.setShader(null); line.setStyle(Paint.Style.STROKE);
            line.setColor(0xE6F8EEFF); line.setStrokeWidth(R * 0.020f);
            c.drawLine(0, 0, 0, -R * 0.22f, line);
            Path bolt = new Path();
            bolt.moveTo(-R * 0.02f, -R * 0.60f);
            bolt.lineTo(R * 0.10f, -R * 0.32f);
            bolt.lineTo(R * 0.02f, -R * 0.32f);
            bolt.lineTo(R * 0.07f, -R * 0.12f);
            bolt.lineTo(-R * 0.08f, -R * 0.36f);
            bolt.lineTo(0, -R * 0.36f);
            bolt.close();
            fill.setShader(new LinearGradient(0, -R * 0.60f, 0, -R * 0.12f,
                    new int[]{0xFFFFFFFF, 0xEBE2BEFF}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            c.drawPath(bolt, fill);
            fill.setShader(null);
            fill.setColor(0xF5FFFFFF);
            c.drawCircle(0, -R * 0.18f, R * 0.05f, fill);
            c.restore();
            /* 肩上的雷纹 */
            line.setShader(null); line.setStyle(Paint.Style.STROKE);
            line.setColor(0x66FFFFFF); line.setStrokeWidth(R * 0.030f);
            line.setStrokeCap(Paint.Cap.ROUND);
            for (int s = -1; s <= 1; s += 2) {
                Path p2 = new Path();
                p2.moveTo(cx + s * R * 0.64f, cy - R * 0.50f);
                p2.lineTo(cx + s * R * 0.56f, cy - R * 0.30f);
                p2.lineTo(cx + s * R * 0.66f, cy - R * 0.26f);
                c.drawPath(p2, line);
            }
        }
    }

    private void drawEyes(Canvas c, float cx, float cy, float R, int i, float t) {
        int eyeCol = EYE[i], core = CORE[i];
        float ex = R * 0.295f, ey = cy + R * 0.005f;
        float w = R * 0.104f, h = R * 0.168f;
        for (int s = -1; s <= 1; s += 2) {
            float px = cx + s * ex + gazeX * R * 0.05f;
            float py = ey + gazeY * R * 0.05f;
            c.save();
            c.translate(px, py);
            c.rotate(s * 7f);
            c.scale(1f, Math.max(0.10f, blink));

            /* 1. 很淡的外发光，只为了让眼睛亮一点，不糊形状 */
            fill.setShader(null);
            fill.setColor(withAlpha(core, 0.13f));
            oval.set(-w * 1.55f, -h * 1.35f, w * 1.55f, h * 1.35f);
            c.drawOval(oval, fill);

            /* 2. 眼窝：比身体深一点的底色，把形状压出来 */
            fill.setColor(withAlpha(core, 0.55f));
            oval.set(-w, -h, w, h);
            c.drawOval(oval, fill);

            /* 3. 眼球：上白下彩 */
            fill.setShader(new LinearGradient(0, -h, 0, h,
                    new int[]{0xFFFDFFF7, withAlpha(eyeCol, 0.99f), withAlpha(core, 0.92f)},
                    new float[]{0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
            oval.set(-w * 0.82f, -h * 0.86f, w * 0.82f, h * 0.86f);
            c.drawOval(oval, fill);
            fill.setShader(null);

            /* 4. 深色描边：给眼睛一个清楚的边界 */
            line.setShader(null);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1.2f, R * 0.016f));
            line.setColor(withAlpha(core, 0.85f));
            oval.set(-w * 0.82f, -h * 0.86f, w * 0.82f, h * 0.86f);
            c.drawOval(oval, line);

            /* 5. 高光 */
            fill.setShader(null);
            fill.setColor(0xFFFFFFFF);
            oval.set(-w * 0.52f, -h * 0.62f, -w * 0.06f, -h * 0.20f);
            c.drawOval(oval, fill);
            fill.setColor(0xCCFFFFFF);
            oval.set(w * 0.08f, h * 0.18f, w * 0.34f, h * 0.38f);
            c.drawOval(oval, fill);

            c.restore();
        }
    }

    private void drawZzz(Canvas c, float x, float y) {
        fill.setShader(null);
        fill.setColor(0xCCFFFFFF);
        fill.setTextSize(Math.max(12f, getWidth() * 0.10f));
        fill.setTextAlign(Paint.Align.CENTER);
        float ph = (time * 40f) % 60f;
        c.drawText("z", x + ph * 0.3f, y - ph, fill);
        fill.setTextSize(Math.max(9f, getWidth() * 0.07f));
        fill.setColor(0x99FFFFFF);
        c.drawText("z", x + 12f + ph * 0.25f, y - ph * 0.7f + 8f, fill);
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    private static int withAlpha(int color, float a) {
        int al = Math.round(Color.alpha(color) * a);
        if (al < 0) al = 0; if (al > 255) al = 255;
        return (al << 24) | (color & 0x00FFFFFF);
    }
}
