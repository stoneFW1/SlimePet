package com.lin.slimepet;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_NOTI = 21;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(44), dp(22), dp(24));
        root.setBackgroundColor(0xFF0B0F17);

        TextView title = new TextView(this);
        title.setText("琳");
        title.setTextSize(36f);
        title.setTextColor(0xFFEAF2FF);
        title.setGravity(Gravity.CENTER);

        TextView sub = new TextView(this);
        sub.setText("会飘在所有 App 上方的史莱姆\n单击换形态 · 双击睡/醒 · 三击回桌面 · 长按出菜单");
        sub.setTextSize(13.5f);
        sub.setTextColor(0xFF8FA2BD);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0f, 1.45f);
        sub.setPadding(0, dp(14), 0, dp(24));

        Button go = mkBtn("让琳出来");
        go.setBackgroundColor(0xFF1D3B2A);
        go.setTextColor(0xFFB9F5C8);
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startPet(); }
        });

        Button hide = mkBtn("让琳收起来");
        hide.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopService(new Intent(MainActivity.this, PetService.class));
                status.setText("琳回去休息了");
            }
        });

        Button shizuku = mkBtn("授权 Shizuku（关机功能要用）");
        shizuku.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (ShizukuShell.canRun()) { status.setText("Shizuku 已授权，菜单里的「关机」可以用"); return; }
                if (!ShizukuShell.needsPermission()) {
                    status.setText("没连上 Shizuku：先装 Shizuku App，并让它启动起来（无线调试或电脑激活一次）");
                    return;
                }
                ShizukuShell.requestPermission();
                status.setText("弹窗里点「允许」，然后回来点刷新");
            }
        });

        /* ---- 数量 ---- */
        EditText countIn = new EditText(this);
        countIn.setHint("宠物数量（比如 3）");
        countIn.setHintTextColor(0xFF5C6C82);
        countIn.setTextColor(0xFFDCE8F8);
        countIn.setTextSize(14f);
        countIn.setSingleLine(true);
        countIn.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        try { countIn.setText(String.valueOf(getSharedPreferences("slimepet", MODE_PRIVATE).getInt("count", 1))); } catch (Exception ignored) {}
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(12);
        countIn.setLayoutParams(clp);

        Button applyCount = mkBtn("应用数量");
        applyCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = 1;
                try { n = Integer.parseInt(countIn.getText().toString().trim()); } catch (Exception ignored) {}
                if (n < 1) n = 1;
                if (n > 60) n = 60;
                getSharedPreferences("slimepet", MODE_PRIVATE).edit().putInt("count", n).apply();
                Intent si = new Intent(MainActivity.this, PetService.class);
                si.setAction(PetService.ACTION_SET_COUNT);
                try { startService(si); } catch (Exception ignored) {}
                status.setText("数量设为 " + n + " 只" + (n > 3 ? "（超过 3 只自动进低配）" : ""));
            }
        });

        /* ---- 物理与行为 ---- */
        Button physBtn = mkBtn("物理 / 行为设置");
        physBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, PhysicsActivity.class)); }
        });

        /* ---- AI Key ---- */
        EditText keyIn = new EditText(this);
        keyIn.setHint("DeepSeek API Key（想让她用 AI 说话才需要）");
        keyIn.setHintTextColor(0xFF5C6C82);
        keyIn.setTextColor(0xFFDCE8F8);
        keyIn.setTextSize(12.5f);
        keyIn.setSingleLine(true);
        try { keyIn.setText(getSharedPreferences("slimepet", MODE_PRIVATE).getString("api_key", "")); } catch (Exception ignored) {}
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        klp.topMargin = dp(16);
        keyIn.setLayoutParams(klp);

        Button saveKey = mkBtn("保存 Key");
        saveKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                getSharedPreferences("slimepet", MODE_PRIVATE)
                        .edit().putString("api_key", keyIn.getText().toString().trim()).apply();
                status.setText("Key 已保存，长按史莱姆 →「让 AI 说一句」");
            }
        });

        Button testKey = mkBtn("测试 AI 连接");
        testKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final String k = getSharedPreferences("slimepet", MODE_PRIVATE).getString("api_key", "").trim();
                if (k.length() < 10) { status.setText("先在上面填 Key 并点「保存 Key」"); return; }
                status.setText("测试中…（" + k.length() + " 位 Key）");
                new Thread(new Runnable() {
                    @Override public void run() {
                        String out;
                        try {
                            String body = "{\"model\":\"deepseek-chat\",\"max_tokens\":30,"
                                    + "\"messages\":[{\"role\":\"user\",\"content\":\"说一句话，20字以内\"}]}";
                            HttpURLConnection c = (HttpURLConnection) new URL("https://api.deepseek.com/chat/completions").openConnection();
                            c.setRequestMethod("POST");
                            c.setConnectTimeout(10000);
                            c.setReadTimeout(15000);
                            c.setRequestProperty("Content-Type", "application/json");
                            c.setRequestProperty("Authorization", "Bearer " + k);
                            c.setDoOutput(true);
                            OutputStream os = c.getOutputStream();
                            os.write(body.getBytes("UTF-8"));
                            os.flush(); os.close();
                            int code = c.getResponseCode();
                            BufferedReader br = new BufferedReader(new InputStreamReader(
                                    code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), "UTF-8"));
                            StringBuilder sb = new StringBuilder(); String ln;
                            while ((ln = br.readLine()) != null) sb.append(ln);
                            br.close();
                            String txt = sb.toString();
                            if (code >= 200 && code < 300) {
                                int i = txt.indexOf("\"content\":");
                                int q1 = i > 0 ? txt.indexOf('"', i + 10) : -1;
                                int q2 = q1 > 0 ? txt.indexOf('"', q1 + 1) : -1;
                                out = (q1 > 0 && q2 > q1)
                                        ? "✅ 连通，她回：" + txt.substring(q1 + 1, q2)
                                        : "⚠️ 连上了但解析失败：" + txt.substring(0, Math.min(120, txt.length()));
                            } else {
                                out = "❌ HTTP " + code + "：" + txt.substring(0, Math.min(160, txt.length()));
                            }
                        } catch (Exception e) {
                            out = "❌ " + e.getClass().getSimpleName() + "：" + e.getMessage();
                        }
                        final String res = out;
                        runOnUiThread(new Runnable() { @Override public void run() { status.setText(res); } });
                    }
                }).start();
            }
        });

        Button refresh = mkBtn("刷新状态");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refreshStatus(); }
        });

        status = new TextView(this);
        status.setTextSize(13f);
        status.setTextColor(0xFF9FB2C9);
        status.setGravity(Gravity.CENTER);
        status.setLineSpacing(0f, 1.5f);
        status.setPadding(dp(6), dp(20), dp(6), dp(6));

        root.addView(title);
        root.addView(sub);
        root.addView(go);
        root.addView(hide);
        root.addView(shizuku);
        root.addView(countIn);
        root.addView(applyCount);
        root.addView(physBtn);
        root.addView(keyIn);
        root.addView(saveKey);
        root.addView(testKey);
        root.addView(refresh);
        TextView help = new TextView(this);
        help.setTextSize(12f);
        help.setTextColor(0xFF6E7F96);
        help.setLineSpacing(0f, 1.5f);
        help.setPadding(dp(2), dp(18), dp(2), dp(6));
        help.setText("怎么玩：\n"
                + "· 单击：换一种元素形态（不说话）\n"
                + "· 双击：让她睡 / 叫醒\n"
                + "· 三击：回桌面\n"
                + "· 拖动：随便放，甩出去会飞\n"
                + "· 长按：菜单（换形态、大小、说话、活动范围、多只、关机…）\n"
                + "· 碰到屏幕边会爬上去，爬到天花板再从另一边下来\n"
                + "· 多只时会互相碰撞弹开（动量守恒），也可以自己画活动范围");
        root.addView(help);
        root.addView(status);

        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);

        askNotification();
        refreshStatus();
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private Button mkBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14f);
        b.setAllCaps(false);
        b.setTextColor(0xFFDCE8F8);
        b.setBackgroundColor(0xFF17202E);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(9);
        b.setLayoutParams(lp);
        return b;
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean overlay = Settings.canDrawOverlays(this);
        boolean acc = PetAccess.ready();
        boolean sz = ShizukuShell.canRun();
        boolean szPend = ShizukuShell.needsPermission();
        StringBuilder sb = new StringBuilder();
        sb.append(overlay ? "✅ 悬浮窗权限已开" : "❌ 悬浮窗权限未开（必须先开）");
        sb.append("\n");
        sb.append(sz ? "✅ Shizuku 已授权（菜单里的关机可用）"
                : (szPend ? "○ Shizuku 已连上，但还没授权" : "○ Shizuku 未连上（不影响日常使用）"));
        sb.append("\n");
        sb.append(acc ? "✅ 无障碍已开（备用的返回方式）" : "○ 无障碍未开（开不了也没关系）");
        String k = "";
        try { k = getSharedPreferences("slimepet", MODE_PRIVATE).getString("api_key", ""); } catch (Exception ignored) {}
        sb.append("\n");
        sb.append(k.length() > 10 ? "✅ API Key 已保存（" + k.length() + " 位）" : "○ 还没保存 API Key");
        sb.append("\n手势：单击换形态 · 双击睡/醒 · 三击回桌面 · 长按菜单");
        status.setText(sb.toString());
    }

    private void startPet() {
        if (!Settings.canDrawOverlays(this)) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
            status.setText("请先打开「显示在其他应用上层」，再回来点一次");
            return;
        }
        Intent s = new Intent(this, PetService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
        else startService(s);
        status.setText("琳出来了：能拖能甩 · 单击换形态 · 双击睡/醒 · 三击回桌面 · 长按菜单");
    }

    private void askNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        }
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
