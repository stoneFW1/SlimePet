package com.lin.slimepet;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_NOTI = 21;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(44), dp(22), dp(24));
        root.setBackgroundColor(0xFF0B0F17);

        TextView title = new TextView(this);
        title.setText("琳");
        title.setTextSize(36f);
        title.setTextColor(0xFFEAF2FF);
        title.setGravity(Gravity.CENTER);

        TextView sub = new TextView(this);
        sub.setText("会飘在所有 App 上方的史莱姆\n单击摸摸 · 双击退出当前页 · 长按菜单");
        sub.setTextSize(13.5f);
        sub.setTextColor(0xFF8FA2BD);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0f, 1.45f);
        sub.setPadding(0, dp(14), 0, dp(24));

        Button go = mkBtn("让琳出来");
        go.setBackgroundColor(0xFF1D3B2A);
        go.setTextColor(0xFFB9F5C8);
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startPet(); }
        });

        Button hide = mkBtn("让琳收起来");
        hide.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopService(new Intent(MainActivity.this, PetService.class));
                status.setText("琳回去休息了");
            }
        });

        Button shizuku = mkBtn("授权 Shizuku（双击返回/强杀靠它）");
        shizuku.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (ShizukuShell.canRun()) { status.setText("Shizuku 已经能用了"); return; }
                if (!ShizukuShell.needsPermission()) {
                    status.setText("没连上 Shizuku：先装 Shizuku App，并让它启动起来（无线调试或电脑激活一次）");
                    return;
                }
                ShizukuShell.requestPermission();
                status.setText("弹窗里点「允许」，然后回来点刷新");
            }
        });

        Button acc = mkBtn("开启无障碍（备用返回方式）");
        acc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    status.setText("在无障碍列表里找到「琳」，打开开关，再回来");
                } catch (Exception e) {
                    status.setText("打不开无障碍设置，请手动进：设置 → 辅助功能 → 无障碍");
                }
            }
        });

        EditText keyIn = new EditText(this);
        keyIn.setHint("DeepSeek API Key（想让她用 AI 说话才需要）");
        keyIn.setHintTextColor(0xFF5C6C82);
        keyIn.setTextColor(0xFFDCE8F8);
        keyIn.setTextSize(12.5f);
        keyIn.setSingleLine(true);
        try { keyIn.setText(getSharedPreferences("slimepet", MODE_PRIVATE).getString("api_key", "")); } catch (Exception ignored) {}
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        klp.topMargin = dp(16);
        keyIn.setLayoutParams(klp);

        Button saveKey = mkBtn("保存 Key");
        saveKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                getSharedPreferences("slimepet", MODE_PRIVATE)
                        .edit().putString("api_key", keyIn.getText().toString().trim()).apply();
                status.setText("Key 已保存，长按史莱姆 → 「说句话（AI）」");
            }
        });

        Button refresh = mkBtn("刷新状态");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refreshStatus(); }
        });

        status = new TextView(this);
        status.setTextSize(13f);
        status.setTextColor(0xFF9FB2C9);
        status.setGravity(Gravity.CENTER);
        status.setLineSpacing(0f, 1.5f);
        status.setPadding(dp(6), dp(20), dp(6), dp(6));

        root.addView(title);
        root.addView(sub);
        root.addView(go);
        root.addView(hide);
        root.addView(shizuku);
        root.addView(acc);
        root.addView(keyIn);
        root.addView(saveKey);
        root.addView(refresh);
        root.addView(status);

        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);

        askNotification();
        refreshStatus();
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private Button mkBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14f);
        b.setAllCaps(false);
        b.setTextColor(0xFFDCE8F8);
        b.setBackgroundColor(0xFF17202E);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(9);
        b.setLayoutParams(lp);
        return b;
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean overlay = Settings.canDrawOverlays(this);
        boolean acc = PetAccess.ready();
        boolean sz = ShizukuShell.canRun();
        boolean szPend = ShizukuShell.needsPermission();
        StringBuilder sb = new StringBuilder();
        sb.append(overlay ? "✅ 悬浮窗权限已开" : "❌ 悬浮窗权限未开（必须先开）");
        sb.append("\n");
        sb.append(sz ? "✅ Shizuku 已授权：双击=返回，菜单=强杀当前 App"
                : (szPend ? "○ Shizuku 已连上，但还没授权" : "○ Shizuku 未连上"));
        sb.append("\n");
        sb.append(acc ? "✅ 无障碍已开（备用的返回方式）" : "○ 无障碍未开（开不了也没关系）");
        sb.append("\n\n双击优先级：Shizuku → 无障碍 → 回桌面");
        status.setText(sb.toString());
    }

    private void startPet() {
        if (!Settings.canDrawOverlays(this)) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
            status.setText("请先打开「显示在其他应用上层」，再回来点一次");
            return;
        }
        Intent s = new Intent(this, PetService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
        else startService(s);
        status.setText("琳出来了：拖着能换位置，甩出去会弹，长按出菜单");
    }

    private void askNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        }
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
