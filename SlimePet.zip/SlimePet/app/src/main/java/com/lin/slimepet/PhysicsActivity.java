package com.lin.slimepet;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** 物理手感：重力 / 弹性 / 摩擦 / 抛掷 / 顶部反弹 / 多宠碰撞 / 低配模式 */
public class PhysicsActivity extends Activity {

    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("slimepet", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(40), dp(20), dp(24));
        root.setBackgroundColor(0xFF0B0F17);

        TextView title = new TextView(this);
        title.setText("物理手感");
        title.setTextSize(24f);
        title.setTextColor(0xFFEAF2FF);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("改完立刻生效，不用重启桌宠");
        hint.setTextSize(12.5f);
        hint.setTextColor(0xFF7D8CA3);
        hint.setPadding(0, dp(6), 0, dp(16));
        root.addView(hint);

        addSlider(root, "重力", "gravity", 0, 3000, 2600, " px/s²");
        addSlider(root, "碰边弹性", "bounce", 0, 100, 45, " %");
        addSlider(root, "地面摩擦", "friction", 0, 100, 40, " %");
        addSlider(root, "抛掷力度", "throw", 50, 200, 110, " %");

        addSwitch(root, "顶部反弹", "top_bounce", true, "关掉后可以把她甩出屏幕顶部再落回来");
        addSwitch(root, "多宠碰撞", "multi_collide", true, "两只以上时按动量守恒互相弹开");
        addSwitch(root, "低配模式", "low_spec", false, "物理降到 30fps 并关闭碰撞，省电");

        Button back = new Button(this);
        back.setText("返回");
        back.setTextSize(14f);
        back.setAllCaps(false);
        back.setTextColor(0xFFDCE8F8);
        back.setBackgroundColor(0xFF17202E);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(22);
        back.setLayoutParams(lp);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        root.addView(back);

        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);
    }

    private void addSlider(LinearLayout box, String label, final String key,
                           final int min, final int max, int def, final String unit) {
        final TextView name = new TextView(this);
        name.setTextSize(13.5f);
        name.setTextColor(0xFFDCE8F8);
        final int cur = sp.getInt(key, def);
        name.setText(label + "　" + cur + unit);
        name.setPadding(0, dp(12), 0, 0);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(Math.max(0, Math.min(max - min, cur - min)));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int val = min + progress;
                name.setText(label + "　" + val + unit);
                if (fromUser) sp.edit().putInt(key, val).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        box.addView(name);
        box.addView(bar);
    }

    private void addSwitch(LinearLayout box, String label, final String key, boolean def, String note) {
        Switch sw = new Switch(this);
        sw.setText(label + "（" + note + "）");
        sw.setTextSize(13f);
        sw.setTextColor(0xFFDCE8F8);
        sw.setPadding(0, dp(14), 0, 0);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                sp.edit().putBoolean(key, v).apply();
            }
        });
        box.addView(sw);
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
