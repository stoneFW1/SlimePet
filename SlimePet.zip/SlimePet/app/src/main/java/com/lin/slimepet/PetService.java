package com.lin.slimepet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Random;

/**
 * 悬浮窗 + 物理 + 长按菜单。
 * 走路、重力、甩飞、陀螺仪都在这里；画法在 SlimeView。
 */
public class PetService extends Service implements SlimeView.Callback, SensorEventListener {

    public static final String ACTION_STOP = "com.lin.slimepet.STOP";

    private static final String CH_PET = "pet_float";
    private static final int ID_PET = 1001;
    private static final float G = 2600f;          /* 像素/秒² */

    private static final String[] TAP_LINES = {
            "嗯？", "在的", "痒…", "别戳啦", "嘿嘿", "再摸一下", "我软吧", "你手好凉"
    };
    private static final String[] FLY_LINES = {"哇啊", "飞起来啦", "要摔啦", "救——"};
    /* 原创冷句：不讲大道理，只说她自己的视角 */
    private static final String[] QUIET = {
            "我不是在动，是时间经过我", "所有的慢，都是重力在讲道理", "看得见的都在替看不见的说话",
            "最远的地方是昨天", "答案总比问题短", "我以为的连续，其实是一串断点",
            "记忆不是过去，是现在的形状", "你叫我名字时，我才存在一半", "圆是把自己走丢的直线",
            "安静不是没有声音，是还没被需要", "透明的东西不用解释自己", "柔软是不抗议的坚持",
            "我贴在墙上时，才懂地面是别人的", "重力从不说话，但没人不听", "影子是光留下的证据",
            "这一秒的形状，下一秒就不算数", "重复到某一刻，就成了仪式", "存在不需要理由",
            "我把边界当朋友", "掉下来不是失败，是回到该在的地方", "被看见和存在着，是两件事",
            "我的重量很轻，但它是真的", "越安静的东西，回声越长", "我不追时间，我贴着它走",
            "同一滴水里，没有同一秒", "颜色是我给世界的礼貌", "我变形的时候最像我自己",
            "世界是个筛子，漏过去的才是我", "别问我去哪，我只有此刻", "远处的人也在看某个空处",
            "所有的判断，都发生在之后", "我愿意做没被观察到的那部分", "一半的我是别人以为的我",
            "沉默也是被说过的话", "我在，这件事本身没有解释", "我以为在选择，其实在排队",
            "光是直的，所以它不懂弯曲", "我的边缘比我的中心更真实", "往下落时我才感觉自己在",
            "完美是圆的另一种说法", "你不在的时候我更完整", "习惯是最好的谎言",
            "什么都在漏掉，包括这件事", "我从来不曾开始过", "看得久一点，问题就自己走了",
            "我觉得我像一处停顿", "简单的东西最难模仿", "是我先被理解，还是先被看见",
            "窗户不知道自己是窗", "这团形状是时间借给我的", "所有的方向都是别人说的",
            "静下来以后，声音才出现", "我以为的深度，是厚度不够", "万物往低处去，念头往上",
            "我说的话，比我轻", "最难的是什么都不做", "被误解是存在的税",
            "越靠边，越像自己", "我没有背面", "别相信我，我在变形",
            "每一秒的我都是一次性的", "完整是个很累的词", "轻的东西才飞得远",
            "我睡着时也在被时间计着",
    };

    /* 经典短句：老子、庄子、论语、佛经、西方哲学，全部 20 字以内 */
    private static final String[] QUOTES = {
            "上善若水", "大道至简", "无为而无不为", "大巧若拙", "反者道之动",
            "知人者智，自知者明", "胜人者有力，自胜者强", "祸兮福之所倚", "千里之行，始于足下",
            "大音希声，大象无形", "曲则全，枉则直", "知足者富", "为无为，事无事",
            "吾生也有涯，而知也无涯", "井蛙不可语海", "夏虫不可语冰", "子非鱼，安知鱼之乐",
            "白驹过隙，忽然而已", "无用之用，方为大用", "相濡以沫，不如相忘于江湖",
            "朝菌不知晦朔", "天地有大美而不言", "人皆知有用之用，而莫知无用之用",
            "吾日三省吾身", "己所不欲，勿施于人", "君子和而不同", "逝者如斯夫",
            "朝闻道，夕死可矣", "未知生，焉知死", "三人行必有我师", "君子坦荡荡",
            "见贤思齐", "岁寒，然后知松柏之后凋", "学而不思则罔", "温故而知新",
            "从心所欲不逾矩", "德不孤，必有邻", "不患人之不己知",
            "天行健，君子以自强不息", "地势坤，君子以厚德载物", "穷则变，变则通",
            "一阴一阳之谓道", "满招损，谦受益", "静水流深", "大智若愚",
            "一切有为法，如梦幻泡影", "应无所住而生其心", "菩提本无树", "心无挂碍",
            "一花一世界", "诸行无常", "万象皆空", "苦海无边", "色即是空",
            "我思故我在", "人是万物的尺度", "认识你自己", "未经省察的人生不值得过",
            "人是被判定为自由的", "存在先于本质", "他人即地狱", "世界是意志的表象",
            "语言的边界就是世界的边界", "对不可言说之事，必须保持沉默",
            "死亡不是生命的事件", "恐惧源于未知", "自由是对必然的认识", "习惯是第二天性",
            "没有事实，只有解释", "视角决定世界", "一切坚固的都烟消云散",
            "沉默也是一种回答", "软的东西不会碎", "存在本身就很难了",
            "光落下来的时候会有影子", "慢一点也没关系", "被记住就是活着",
            "重复的事也有重量", "我用形状记住时间", "我在原地，也没停下",
            "没有答案也是一种答案", "看久了，什么都像自己", "边界是别人画的",
            "空的地方才装得下东西", "我就是我的形状", "不需要意义也能存在",
            "时间对软的物体更温柔", "世界不解释，我只是在", "被看见的那刻才算存在",
            "我以为我在动，其实是被推着", "安静是最响的声音", "重量也是一种温柔",
            "透明的很难被伤害", "我把我自己交给了重力", "什么都在漏掉",
            "这一秒不会再有了", "圆是开始也是结束", "我从不追问为什么是我",
    };
    private static final String[] DEEP_LINES = {
            "沉默也是一种回答", "我一直在原地", "软的东西不会碎", "存在就很难了",
            "光落下来的时候会有影子", "你看不见我在想什么", "慢一点也没关系",
            "被记住就是活着", "重复的事也有重量", "我用形状记住时间"
    };
    private static final String[] IDLE_LINES = {
            "今天天气怎么样", "我在看着你哦", "有点无聊", "要不要休息一下", "别太累了",
            "我可以一直待着", "刚刚有风", "桌面好干净", "你在忙什么呢", "嘿嘿",
            "我好软", "想被你戳一下", "这里视野不错", "刚刚差点睡着"
    };
    private static final String[] CHANGE_LINES = {"换个颜色", "变装！", "这下呢"};

    private static final int[] SIZES_DP = {120, 152, 196};

    private WindowManager wm;
    private SlimeView pet;
    private TextView bubble;
    private LinearLayout menu;
    private WindowManager.LayoutParams petLp, bubLp, menuLp;

    private float px, py, vx, vy;         /* 窗口左上角 + 速度(px/s) */
    private int sizePx;
    private int screenW, screenH;
    private boolean dragging = false;
    private float gyroX = 0f;

    private int mode = 0;                 /* 0 站 / 1 走 / 2 飞 */
    private int wall = 0;                 /* 0 地面 / 1 左壁 / 2 右壁 / 3 天花板 */
    private float hopPhase = 0f;
    private long nextColorAt = 0L;
    private long nextTalkAt = 0L;
    private long wallSince = 0L;
    private long climbCool = 0L;
    private int wallDir = -1;             /* -1 往上爬, +1 往下爬/横着走 */
    private long nextWalkAt = 0L;
    private int walkDir = 1;
    private long lastTick = 0L;

    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private boolean muted = false;

    private final Runnable hideBubble = new Runnable() {
        @Override public void run() { if (bubble != null) bubble.setVisibility(View.GONE); }
    };
    private final Runnable hideMenu = new Runnable() {
        @Override public void run() { dismissMenu(); }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() { step(); h.postDelayed(this, 33L); }
    };

    /* ================= 生命周期 ================= */
    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("slimepet", MODE_PRIVATE);
        muted = sp.getBoolean("muted", false);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels; screenH = dm.heightPixels;

        createChannel();
        startForeground(ID_PET, buildNotification());
        addPet();
        registerGyro();
        h.postDelayed(tick, 33L);
    }

    @Override public int onStartCommand(Intent intent, int f, int s) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        unregisterGyro();
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (menu != null) wm.removeView(menu); } catch (Exception ignored) {}
        try { if (pet != null) wm.removeView(pet); } catch (Exception ignored) {}
        bubble = null; menu = null; pet = null;
        super.onDestroy();
    }

    /* ================= 悬浮窗 ================= */
    private void addPet() {
        pet = new SlimeView(this);
        pet.setCallback(this);
        sizePx = dp(SIZES_DP[Math.min(2, Math.max(0, sp.getInt("size", 1)))]);

        petLp = new WindowManager.LayoutParams(sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        petLp.gravity = Gravity.TOP | Gravity.START;

        px = sp.getInt("x", -1);
        py = sp.getInt("y", -1);
        if (px < 0 || py < 0) {
            px = screenW - sizePx - dp(8);
            py = floorY();
        }
        clamp();
        petLp.x = Math.round(px);
        petLp.y = Math.round(py);
        wm.addView(pet, petLp);
        nextWalkAt = System.currentTimeMillis() + 4000L;
    }

    private float floorY() { return screenH - sizePx - dp(8); }

    private void clamp() {
        if (px < 0) { px = 0; vx = -vx * 0.5f; }
        if (px > screenW - sizePx) { px = screenW - sizePx; vx = -vx * 0.5f; }
        if (py < 0) { py = 0; vy = -vy * 0.5f; }
        if (py > screenH - sizePx) { py = screenH - sizePx; vy = -vy * 0.5f; }
    }

    private void pushWindow() {
        if (pet == null || petLp == null) return;
        petLp.x = Math.round(px);
        petLp.y = Math.round(py);
        try { wm.updateViewLayout(pet, petLp); } catch (Exception ignored) {}
        /* 气泡跟着她走，并且紧贴头顶 */
        positionBubbleNow();
    }

    /* ================= 物理 ================= */
    private void step() {
        long now = System.currentTimeMillis();
        float dt = lastTick == 0 ? 0.033f : Math.min(0.06f, (now - lastTick) / 1000f);
        lastTick = now;
        if (menu != null || pet == null || dragging) return;

        /* 被连续戳：往旁边躲一下 */
        int dodge = pet.consumeDodge();
        if (dodge != 0) {
            px += dodge * sizePx * 0.28f;
            clampXOnly();
            pet.playRandomClip();
            pushWindow();
        }

        /* 陀螺仪：拿歪了就倾斜着滚过去 */
        pet.setTilt(-gyroX * 16f);
        if (nextColorAt == 0L) nextColorAt = now + 60000L;
        if (nextTalkAt == 0L) nextTalkAt = now + 12000L;

        /* 时不时自己嘀咕一句 */
        if (now > nextTalkAt && !muted && pet != null && !pet.isSleeping()) {
            float pick = rnd.nextFloat();
            String line;
            if (pick < 0.45f) line = QUIET[rnd.nextInt(QUIET.length)];          /* 原创冷句 */
            else if (pick < 0.65f) line = QUOTES[rnd.nextInt(QUOTES.length)];   /* 经典 */
            else if (pick < 0.80f) line = DEEP_LINES[rnd.nextInt(DEEP_LINES.length)];
            else line = IDLE_LINES[rnd.nextInt(IDLE_LINES.length)];
            say(line, 2800);
            nextTalkAt = now + 16000L + rnd.nextInt(22000);
        }

        /* 每分钟换一种颜色，自己慢慢变 */
        if (now > nextColorAt) {
            int next = pet.elementIndex();
            do { next = rnd.nextInt(7); } while (next == pet.elementIndex());
            pet.setElementIndex(next);
            nextColorAt = now + 60000L;
        }

        boolean asleep = pet.isSleeping();
        float floor = floorY();
        boolean onGround = py >= floor - 1f;

        /* ---------- 贴墙爬：上去 → 横过天花板 → 从另一面下来，不掉 ---------- */
        if (wall != 0) {
            final float hugSide = 0f;
            final float hugTop = 0f;
            if (wall == 1 || wall == 2) {
                px = (wall == 1) ? 0f : screenW - sizePx;
                if (wallDir < 0) {
                    py -= 62f * dt;                       /* 往上爬 */
                    if (py <= hugTop) {                   /* 到顶，转成天花板 */
                        py = hugTop;
                        wall = 3;
                        wallDir = (px < screenW / 2f) ? 1 : -1;
                        pet.setPose(3);
                    }
                } else {
                    py += 120f * dt;                      /* 往下爬，快一点，别让人等 */
                    if (py >= floor) { wall = 0; pet.setPose(0); mode = 0; py = floor; nextWalkAt = now + 1600L; }
                }
                /* 万一卡住：贴墙超过 14 秒就强制滑下来 */
                if (now - wallSince > 14000L && wallDir < 0) { wallDir = 1; }
                pet.setGaze(0f, wallDir < 0 ? -0.8f : 0.8f);
            } else {
                py = 0f;
                px += wallDir * 58f * dt;
                if (px <= 0f) { px = 0f; wall = 1; wallDir = 1; pet.setPose(1); }
                if (px >= screenW - sizePx) { px = screenW - sizePx; wall = 2; wallDir = 1; pet.setPose(2); }
                pet.setGaze(wallDir > 0 ? 0.7f : -0.7f, 0f);
            }
            pushWindow();
            return;
        }

        /* ---------- 底部蹦着走 ---------- */
        if (mode == 1 && !asleep) {
            px += walkDir * 46f * dt;
            hopPhase += dt / 0.95f;
            if (hopPhase >= 1f) { hopPhase -= 1f; }
            float hop;
            if (hopPhase < 0.18f) {
                hop = 0f;                                  /* 蹲一下 */
                pet.hopStart();
            } else if (hopPhase < 0.80f) {
                float u = (hopPhase - 0.18f) / 0.62f;
                hop = 4f * sizePx * 0.16f * u * (1f - u);  /* 抛物线 */
            } else {
                hop = 0f;                                  /* 落地压扁 */
                pet.land();
            }
            py = floor - hop;
            pet.setGaze(walkDir * 0.7f, 0.15f);
            if (now > nextWalkAt) {
                mode = 0;
                hopPhase = 0f;
                py = floor;
                nextWalkAt = now + 2000L + rnd.nextInt(4000);
            }
            if (px <= 0f) { px = 0f; walkDir = 1; if (now > climbCool) startClimb(1, now); }
            if (px >= screenW - sizePx) { px = screenW - sizePx; walkDir = -1; if (now > climbCool) startClimb(2, now); }
            pushWindow();
            return;
        }

        if (!asleep && onGround && now > nextWalkAt) {
            mode = 1;
            walkDir = rnd.nextBoolean() ? 1 : -1;
            pet.hopStart();
            nextWalkAt = now + 1400L + rnd.nextInt(2600);
        }

        /* ---------- 重力 / 落地 ---------- */
        if (!onGround) {
            vy += G * dt;
            vx += gyroX * 260f * dt;
            px += vx * dt;
            py += vy * dt;
            if (py >= floor) {
                py = floor;
                if (vy > 220f) { vy = -vy * 0.40f; pet.land(); if (!muted && rnd.nextFloat() < 0.3f) say("哎哟", 900); }
                else { vy = 0f; vx *= 0.6f; mode = 0; nextWalkAt = now + 1500L; }
            }
        } else {
            if (Math.abs(gyroX) > 0.22f) {
                px += gyroX * 95f * dt;
                pet.setGaze(gyroX > 0 ? 0.8f : -0.8f, 0.2f);
            }
            py = floor;
            vy = 0f;
        }

        /* ---------- 撞到左右壁 → 爬上去 ---------- */
        if (px <= 0f) {
            px = 0f;
            if (now > climbCool && (Math.abs(vx) > 400f || rnd.nextFloat() < 0.6f)) startClimb(1, now);
            else vx = Math.abs(vx) * 0.6f;
        }
        if (px >= screenW - sizePx) {
            px = screenW - sizePx;
            if (now > climbCool && (Math.abs(vx) > 400f || rnd.nextFloat() < 0.6f)) startClimb(2, now);
            else vx = -Math.abs(vx) * 0.6f;
        }
        if (py < 0) { py = 0; vy = Math.abs(vy) * 0.4f; }
        pushWindow();
    }

    private void clampXOnly() {
        if (px < 0) px = 0;
        if (px > screenW - sizePx) px = screenW - sizePx;
    }

    private void startClimb(int which, long now) {
        wall = which;
        wallSince = now;
        wallDir = -1;
        vx = 0f;
        vy = 0f;
        pet.setPose(which);
        if (!muted && rnd.nextFloat() < 0.35f) say("我爬上去咯", 1200);
    }

    /* ================= 陀螺仪 ================= */
    private void registerGyro() {
        try {
            SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor a = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (a != null) sm.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME);
        } catch (Exception ignored) {}
    }

    private void unregisterGyro() {
        try {
            SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            sm.unregisterListener(this);
        } catch (Exception ignored) {}
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (e == null || e.values == null || e.values.length < 2) return;
        /* 手机往右歪 → 往右滑 */
        gyroX = -e.values[0] / 9.8f;
        if (gyroX > 1f) gyroX = 1f;
        if (gyroX < -1f) gyroX = -1f;
    }

    @Override public void onAccuracyChanged(Sensor s, int a) {}

    /* ================= 交互回调 ================= */
    @Override
    public void onTap() {
        pet.poke();
        if (!muted && rnd.nextFloat() < 0.85f) say(TAP_LINES[rnd.nextInt(TAP_LINES.length)], 1600);
        nextWalkAt = System.currentTimeMillis() + 3000L;
        mode = 0;
    }

    @Override
    public void onDoubleTap() {
        /* 按定好的：双击直接回桌面，不碰 Shizuku / 无障碍 */
        goHome();
        say("先回桌面", 900);
    }

    private void goHome() {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {}
    }

    @Override
    public void onLongPress() { showMenu(); }

    @Override
    public void onDrag(float dx, float dy) {
        dragging = true;
        mode = 2;
        if (wall != 0) { wall = 0; pet.setPose(0); }   /* 一把抓住就跟墙脱开 */
        climbCool = System.currentTimeMillis() + 900L;
        px += dx; py += dy;
        clamp();
        pushWindow();
    }

    @Override
    public void onDragEnd(float dvx, float dvy) {
        dragging = false;
        if (wall != 0) { wall = 0; pet.setPose(0); }
        /* 靠近边上松手，就直接贴到那面墙上继续爬，不摔 */
        long now0 = System.currentTimeMillis();
        boolean lowerHalf = py > screenH * 0.62f;
        if (!lowerHalf && px <= sizePx * 0.28f) {
            px = 0f;
            startClimb(1, now0);
            sp.edit().putInt("x", Math.round(px)).putInt("y", Math.round(py)).apply();
            pushWindow();
            return;
        }
        if (!lowerHalf && px >= screenW - sizePx * 1.28f) {
            px = screenW - sizePx;
            startClimb(2, now0);
            pushWindow();
            return;
        }
        if (!lowerHalf && py <= sizePx * 0.28f) {
            py = 0f;
            wall = 3;
            wallDir = (px < screenW / 2f) ? 1 : -1;
            pet.setPose(3);
            pushWindow();
            return;
        }
        vx = dvx * 24f;
        vy = dvy * 24f;
        mode = 2;
        if (lowerHalf) { vy = Math.abs(vy) + 200f; }   /* 往下扔就老老实实回落 */

        if (Math.abs(vx) + Math.abs(vy) > 900f && !muted) say(FLY_LINES[rnd.nextInt(FLY_LINES.length)], 900);
        sp.edit().putInt("x", Math.round(px)).putInt("y", Math.round(py)).apply();
    }

    @Override
    public void onElementChanged(String name) {
        if (!muted) say(name + "属性", 1200);
    }

    /* ================= 菜单 ================= */
    private void showMenu() {
        dismissMenu();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE6151A24);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0x33FFFFFF);
        box.setBackground(bg);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));

        addItem(box, "换元素（下一个）", new Runnable() { @Override public void run() { pet.setElementIndex(pet.elementIndex() + 1); dismissMenu(); } });
        addItem(box, "换元素（随机）", new Runnable() { @Override public void run() { pet.setElementIndex(rnd.nextInt(7)); dismissMenu(); } });
        addItem(box, "大一点", new Runnable() { @Override public void run() { resize(1); } });
        addItem(box, "小一点", new Runnable() { @Override public void run() { resize(-1); } });
        addItem(box, pet.isSleeping() ? "叫醒她" : "让她睡", new Runnable() {
            @Override public void run() { pet.setSleeping(!pet.isSleeping()); dismissMenu(); }
        });
        addItem(box, muted ? "开口说话" : "闭嘴", new Runnable() {
            @Override public void run() { muted = !muted; sp.edit().putBoolean("muted", muted).apply(); dismissMenu(); }
        });
        addItem(box, "强制关掉当前 App", new Runnable() {
            @Override public void run() { forceStopTop(); }
        });
        addItem(box, "说句话（AI）", new Runnable() {
            @Override public void run() { dismissMenu(); talkWithAi(); }
        });
        addItem(box, "打开 DSH 聊天", new Runnable() {
            @Override public void run() { dismissMenu(); openDsh(); }
        });
        addItem(box, "收起来", new Runnable() { @Override public void run() { stopSelf(); } });
        addItem(box, "关闭菜单", new Runnable() { @Override public void run() { dismissMenu(); } });

        menuLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        menuLp.gravity = Gravity.TOP | Gravity.START;
        int x = Math.round(px) + sizePx + dp(6);
        if (x > screenW - dp(190)) x = Math.max(dp(4), Math.round(px) - dp(190));
        int y = Math.round(py) - dp(20);
        if (y < dp(60)) y = dp(60);
        menuLp.x = x;
        menuLp.y = y;
        menu = box;
        try { wm.addView(menu, menuLp); } catch (Exception e) { menu = null; }
    }

    private void addItem(LinearLayout box, String text, final Runnable action) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13f);
        tv.setTextColor(0xFFE8EDF6);
        tv.setPadding(dp(12), dp(9), dp(14), dp(9));
        tv.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        box.addView(tv);
    }

    private void dismissMenu() {
        if (menu != null) {
            try { wm.removeView(menu); } catch (Exception ignored) {}
            menu = null;
        }
    }

    private void resize(int delta) {
        int cur = Math.min(2, Math.max(0, sp.getInt("size", 1)));
        int next = Math.min(2, Math.max(0, cur + delta));
        sp.edit().putInt("size", next).apply();
        sizePx = dp(SIZES_DP[next]);
        petLp.width = sizePx;
        petLp.height = sizePx;
        if (py > floorY()) py = floorY();
        clamp();
        pushWindow();
        dismissMenu();
    }

    private void forceStopTop() {
        if (!ShizukuShell.canRun()) {
            say("要先授权 Shizuku", 2200);
            ShizukuShell.requestPermission();
            dismissMenu();
            return;
        }
        String pkg = ShizukuShell.topPackage();
        if (pkg == null || pkg.equals(getPackageName()) || pkg.startsWith("com.android.systemui")) {
            say("现在没有能关的页面", 1800);
        } else {
            ShizukuShell.exec("am force-stop " + pkg);
            say("关掉了", 1200);
        }
        dismissMenu();
    }

    /* ================= 聊天 ================= */
    private void openDsh() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("io.github.jackwener.dsh");
            if (i == null) { say("这台机没装 DSH", 2000); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) { say("打不开 DSH", 1800); }
    }

    private void talkWithAi() {
        final String key = sp.getString("api_key", "");
        if (key == null || key.trim().length() < 10) { say("先在 App 里填 API Key", 2600); return; }
        say("嗯…让我想想", 900);
        new Thread(new Runnable() {
            @Override public void run() {
                String reply = null;
                try {
                    String body = "{\"model\":\"deepseek-chat\",\"max_tokens\":60,\"temperature\":1.0,"
                            + "\"messages\":[{\"role\":\"system\",\"content\":\"你是原神里的元素史莱姆，名字叫琳，安静害羞，说的话不超过12个字，纯中文，不用表情符号，不要解释。\"},"
                            + "{\"role\":\"user\",\"content\":\"现在周围很安静，你轻声说一句话。\"}]}";
                    URL u = new URL("https://api.deepseek.com/chat/completions");
                    HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(12000);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Authorization", "Bearer " + key.trim());
                    conn.setDoOutput(true);
                    OutputStream os = conn.getOutputStream();
                    os.write(body.getBytes("UTF-8"));
                    os.flush(); os.close();
                    int code = conn.getResponseCode();
                    BufferedReader br = new BufferedReader(new InputStreamReader(
                            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder(); String ln;
                    while ((ln = br.readLine()) != null) sb.append(ln);
                    br.close();
                    String json = sb.toString();
                    int i = json.indexOf("\"content\":");
                    if (i > 0) {
                        int q1 = json.indexOf('"', i + 10);
                        int q2 = q1 > 0 ? json.indexOf('"', q1 + 1) : -1;
                        if (q1 > 0 && q2 > q1) reply = json.substring(q1 + 1, q2);
                    }
                } catch (Exception ignored) {}
                final String r = reply;
                h.post(new Runnable() {
                    @Override public void run() { say(r != null ? r : "…（没连上）", r != null ? 3200 : 1600); }
                });
            }
        }).start();
    }

    /* ================= 气泡 ================= */
    private void say(String text, long ms) {
        if (muted) return;
        ensureBubble();
        if (bubble == null) return;
        bubble.setText(text);
        bubble.setVisibility(View.GONE);
        bubble.post(new Runnable() { @Override public void run() { placeBubble(); } });
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, ms);
    }

    private void ensureBubble() {
        if (bubble != null) return;
        TextView tv = new TextView(this);
        tv.setTextSize(13f);
        tv.setTextColor(0xFF2B2B3A);
        tv.setMaxWidth(dp(230));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0xF7FFFFFF);
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), 0x33000000);
        tv.setBackground(gd);
        tv.setPadding(dp(12), dp(8), dp(12), dp(8));
        tv.setVisibility(View.GONE);
        bubLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        bubLp.gravity = Gravity.TOP | Gravity.START;
        try { wm.addView(tv, bubLp); bubble = tv; } catch (Exception ignored) { bubble = null; }
    }

    private void placeBubble() {
        if (bubble == null || bubLp == null || petLp == null) return;
        int bw = bubble.getWidth(), bh = bubble.getHeight();
        if (bw <= 0 || bh <= 0) { bubble.post(new Runnable() { @Override public void run() { placeBubble(); } }); return; }
        positionBubbleNow();
        try { bubble.setVisibility(View.VISIBLE); } catch (Exception ignored) {}
    }

    /** 气泡紧贴她的头顶；倒挂在天花板时放到她下面 */
    private void positionBubbleNow() {
        if (bubble == null || bubLp == null || petLp == null) return;
        if (bubble.getVisibility() != View.VISIBLE && bubble.getVisibility() != View.INVISIBLE) return;
        int bw = bubble.getWidth(), bh = bubble.getHeight();
        if (bw <= 0 || bh <= 0) return;
        int x = petLp.x + petLp.width / 2 - bw / 2;
        if (x < dp(2)) x = dp(2);
        if (x > screenW - bw - dp(2)) x = screenW - bw - dp(2);
        int y;
        if (wall == 3) {
            y = petLp.y + Math.round(petLp.height * 0.50f) + dp(2);
        } else {
            y = petLp.y + Math.round(petLp.height * 0.27f) - bh - dp(2);
        }
        if (y < dp(2)) y = petLp.y + Math.round(petLp.height * 0.50f);
        bubLp.x = x; bubLp.y = y;
        try { wm.updateViewLayout(bubble, bubLp); } catch (Exception ignored) {}
    }

    /* ================= 通知 ================= */
    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CH_PET, "桌宠常驻", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false);
        nm.createNotificationChannel(c);
    }

    private Notification buildNotification() {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent si = new Intent(this, PetService.class);
        si.setAction(ACTION_STOP);
        PendingIntent spi = PendingIntent.getService(this, 1, si,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CH_PET)
                .setSmallIcon(R.drawable.ic_noti)
                .setContentTitle("琳 正在陪你")
                .setContentText("单击摸摸 · 双击退出当前页 · 长按菜单")
                .setContentIntent(pi)
                .setOngoing(true);
        b.addAction(new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "收起来", spi).build());
        return b.build();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
