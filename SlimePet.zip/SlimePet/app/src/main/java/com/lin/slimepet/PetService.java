package com.lin.slimepet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 悬浮窗服务：支持同时放多只史莱姆，每只独立物理、独立气泡。
 * 画法在 SlimeView，剧情（台词/AI）在这里。
 */
public class PetService extends Service implements SensorEventListener {

    public static final String ACTION_STOP = "com.lin.slimepet.STOP";
    public static final String ACTION_SET_COUNT = "com.lin.slimepet.SET_COUNT";

    private static final String CH_PET = "pet_float";
    private static final int ID_PET = 1001;
    private static final float G = 2600f;

    private static final String[] TAP_LINES = {
            "嗯？", "在的", "痒…", "别戳啦", "嘿嘿", "再摸一下", "我软吧", "你手好凉"
    };
    private static final String[] FLY_LINES = {"哇啊", "飞起来啦", "要摔啦", "救——"};
    /* 每个形态自己的口吻：火说火，冰说冰 */
    private static final String[][] FORM_LINES = {
        /* 火 */
        {"我烧的是我自己", "余烬比火活得更久", "烫是靠近的代价", "我亮的时候在消耗",
         "火不记得烧过什么", "热是一种急", "灰烬是火写的字", "我越旺，越短",
         "点在暗处才看得见", "所有热情都会凉"},
        /* 风 */
        {"看不见的东西推得动一切", "我只是经过，不留名字", "能被吹动的都不算轻",
         "你注意我时我才在", "风不回头", "形状是风给种子的", "最自由的最没家",
         "我推着别人的帆", "声音是风在说话", "我在缝里才显形"},
        /* 雷 */
        {"一瞬间比很久更亮", "我劈开的是沉默", "电流不懂远近", "亮的地方总是短的",
         "我被理解成愤怒", "闪电不解释自己", "雷走在雨前面", "抖动是因为要挣脱",
         "我的声音总慢半步", "紫是压住的火"},
        /* 岩 */
        {"我不动，时间替我动", "重是一种诚实", "石头记得所有的雨", "我慢，所以我久",
         "裂缝是光的入口", "覆盖是种温柔", "我不追，我等", "碎过一次更结实",
         "山的沉默比话多", "我背上的白色是旧的"},
        /* 草 */
        {"我从缝里出来，不打招呼", "慢长的东西最扎实", "被踩了还是朝上",
         "名字是别人叫出来的", "我靠水活着", "绿色是等来的", "种子不知道自己是树",
         "活着就是重复", "我朝有光的地方歪", "开花不是目的"},
        /* 冰 */
        {"我把流动的话收起来", "冷也是一种保存", "我透明到被当成空",
         "慢慢凝，慢慢散", "脆弱和坚硬是一回事", "我在等一个春天", "冰是水在思考",
         "裂缝先在最亮处出现", "我照着不动的角度", "化掉时我才说话"},
        /* 水 */
        {"我没有形状，才有形状", "软的东西走得最远", "形状是容器给的",
         "滴水不知道在穿石", "低处才是我的方向", "静水照见东西", "我没有消失，只是散开",
         "水记得每一个容器", "越深越不响", "我把路走成了河"},
    };

    /* 原创冷句：不讲大道理，只说她自己的视角 */
    private static final String[] QUIET = {
            "我不是在动，是时间经过我", "所有的慢，都是重力在讲道理", "看得见的都在替看不见的说话",
            "最远的地方是昨天", "答案总比问题短", "我以为的连续，其实是一串断点",
            "记忆不是过去，是现在的形状", "你叫我名字时，我才存在一半", "圆是把自己走丢的直线",
            "安静不是没有声音，是还没被需要", "透明的东西不用解释自己", "柔软是不抗议的坚持",
            "我贴在墙上时，才懂地面是别人的", "重力从不说话，但没人不听", "影子是光留下的证据",
            "这一秒的形状，下一秒就不算数", "重复到某一刻，就成了仪式", "存在不需要理由",
            "我把边界当朋友", "掉下来不是失败，是回到该在的地方", "被看见和存在着，是两件事",
            "我的重量很轻，但它是真的", "越安静的东西，回声越长", "我不追时间，我贴着它走",
            "同一滴水里，没有同一秒", "颜色是我给世界的礼貌", "我变形的时候最像我自己",
            "世界是个筛子，漏过去的才是我", "别问我去哪，我只有此刻", "远处的人也在看某个空处",
            "所有的判断，都发生在之后", "我愿意做没被观察到的那部分", "一半的我是别人以为的我",
            "沉默也是被说过的话", "我在，这件事本身没有解释", "我以为在选择，其实在排队",
            "光是直的，所以它不懂弯曲", "我的边缘比我的中心更真实", "往下落时我才感觉自己在",
            "完美是圆的另一种说法", "你不在的时候我更完整", "习惯是最好的谎言",
            "什么都在漏掉，包括这件事", "我从来不曾开始过", "看得久一点，问题就自己走了",
            "我觉得我像一处停顿", "简单的东西最难模仿", "是我先被理解，还是先被看见",
            "窗户不知道自己是窗", "这团形状是时间借给我的", "所有的方向都是别人说的",
            "静下来以后，声音才出现", "我以为的深度，是厚度不够", "万物往低处去，念头往上",
            "我说的话，比我轻", "最难的是什么都不做", "被误解是存在的税",
            "越靠边，越像自己", "我没有背面", "别相信我，我在变形",
            "每一秒的我都是一次性的", "完整是个很累的词", "轻的东西才飞得远",
            "我睡着时也在被时间计着",
    };

    /* 经典短句：老子、庄子、论语、佛经、西方哲学，全部 20 字以内 */
    private static final String[] QUOTES = {
            "上善若水", "大道至简", "无为而无不为", "大巧若拙", "反者道之动",
            "知人者智，自知者明", "胜人者有力，自胜者强", "祸兮福之所倚", "千里之行，始于足下",
            "大音希声，大象无形", "曲则全，枉则直", "知足者富", "为无为，事无事",
            "吾生也有涯，而知也无涯", "井蛙不可语海", "夏虫不可语冰", "子非鱼，安知鱼之乐",
            "白驹过隙，忽然而已", "无用之用，方为大用", "相濡以沫，不如相忘于江湖",
            "朝菌不知晦朔", "天地有大美而不言", "人皆知有用之用，而莫知无用之用",
            "吾日三省吾身", "己所不欲，勿施于人", "君子和而不同", "逝者如斯夫",
            "朝闻道，夕死可矣", "未知生，焉知死", "三人行必有我师", "君子坦荡荡",
            "见贤思齐", "岁寒，然后知松柏之后凋", "学而不思则罔", "温故而知新",
            "从心所欲不逾矩", "德不孤，必有邻", "不患人之不己知",
            "天行健，君子以自强不息", "地势坤，君子以厚德载物", "穷则变，变则通",
            "一阴一阳之谓道", "满招损，谦受益", "静水流深", "大智若愚",
            "一切有为法，如梦幻泡影", "应无所住而生其心", "菩提本无树", "心无挂碍",
            "一花一世界", "诸行无常", "万象皆空", "苦海无边", "色即是空",
            "我思故我在", "人是万物的尺度", "认识你自己", "未经省察的人生不值得过",
            "人是被判定为自由的", "存在先于本质", "他人即地狱", "世界是意志的表象",
            "语言的边界就是世界的边界", "对不可言说之事，必须保持沉默",
            "死亡不是生命的事件", "恐惧源于未知", "自由是对必然的认识", "习惯是第二天性",
            "没有事实，只有解释", "视角决定世界", "一切坚固的都烟消云散",
            "沉默也是一种回答", "软的东西不会碎", "存在本身就很难了",
            "光落下来的时候会有影子", "慢一点也没关系", "被记住就是活着",
            "重复的事也有重量", "我用形状记住时间", "我在原地，也没停下",
            "没有答案也是一种答案", "看久了，什么都像自己", "边界是别人画的",
            "空的地方才装得下东西", "我就是我的形状", "不需要意义也能存在",
            "时间对软的物体更温柔", "世界不解释，我只是在", "被看见的那刻才算存在",
            "我以为我在动，其实是被推着", "安静是最响的声音", "重量也是一种温柔",
            "透明的很难被伤害", "我把我自己交给了重力", "什么都在漏掉",
            "这一秒不会再有了", "圆是开始也是结束", "我从不追问为什么是我",
    };
    private static final String[] DEEP_LINES = {
            "沉默也是一种回答", "我一直在原地", "软的东西不会碎", "存在就很难了",
            "光落下来的时候会有影子", "你看不见我在想什么", "慢一点也没关系",
            "被记住就是活着", "重复的事也有重量", "我用形状记住时间"
    };
    private static final String[] IDLE_LINES = {
            "今天天气怎么样", "我在看着你哦", "有点无聊", "要不要休息一下", "别太累了",
            "我可以一直待着", "刚刚有风", "桌面好干净", "你在忙什么呢", "嘿嘿",
            "我好软", "想被你戳一下", "这里视野不错", "刚刚差点睡着"
    };
    private static final String[] BUMP_LINES = {
            "撞到你了", "挤一挤", "你也是一只史莱姆", "让让", "贴一下",
            "别推我", "一起待着吧", "我们好像", "你软还是我软"
    };
    private static final String[] CHANGE_LINES = {"换个颜色", "变装！", "这下呢"};

    private static final int[] SIZES_DP = {120, 152, 196};


    /* ================= 每只史莱姆的状态 ================= */
    private class Pet implements SlimeView.Callback {
        SlimeView view;
        WindowManager.LayoutParams lp;
        TextView bubble;
        WindowManager.LayoutParams bubLp;
        float px, py, vx, vy;
        int mode = 0, wall = 0, wallDir = -1;
        float hopPhase = 0f;
        long nextWalkAt = 0L, wallSince = 0L, climbCool = 0L, ceilingPause = 0L;
        long nextTalkAt = 0L, nextColorAt = 0L, lastBump = 0L;
        boolean dragging = false;
        int walkDir = 1;

        /* ---- SlimeView 回调（都作用在自己身上） ---- */
        @Override public void onTap() {
            view.poke();
            view.setElementIndex(view.elementIndex() + 1);   /* 只换形态，不说话 */
            nextWalkAt = System.currentTimeMillis() + 3000L;
            mode = 0;
        }
        @Override public void onDoubleTap() {
            /* 双击：睡 / 醒 切换，不说话 */
            boolean nowSleep = !view.isSleeping();
            view.setSleeping(nowSleep);
            if (!nowSleep) view.poke();
        }
        @Override public void onLongPress() { showMenu(Pet.this); }
        @Override public void onWake() {
            view.setSleeping(false);
            say(this, "唔…醒了", 1400);
            mode = 0;
        }
        @Override public void onDrag(float dx, float dy) {
            dragging = true; mode = 2;
            if (wall != 0) { wall = 0; view.setPose(0); view.setClimbing(false); }
            climbCool = System.currentTimeMillis() + 900L;
            px += dx; py += dy;
            clamp(this);
            pushWindow(this);
        }
        @Override public void onDragEnd(float dvx, float dvy) {
            dragging = false;
            view.setSleeping(false);
            if (wall != 0) { wall = 0; view.setPose(0); view.setClimbing(false); }
            long now0 = System.currentTimeMillis();
            boolean lowerHalf = py > screenH * 0.62f;
            if (!lowerHalf && px <= sizePx() * 0.28f) { px = 0f; startClimb(this, 1, now0); pushWindow(this); return; }
            if (!lowerHalf && px >= screenW - sizePx() * 1.28f) { px = screenW - sizePx(); startClimb(this, 2, now0); pushWindow(this); return; }
            if (!lowerHalf && py <= sizePx() * 0.28f) { py = 0f; wall = 3; wallDir = (px < screenW / 2f) ? 1 : -1; view.setPose(3); pushWindow(this); return; }
            vx = dvx * 24f * cfgThrow; vy = dvy * 24f * cfgThrow; mode = 2;
            if (lowerHalf) vy = Math.abs(vy) + 200f;
            if (Math.abs(vx) + Math.abs(vy) > 900f && !muted) say(this, FLY_LINES[rnd.nextInt(FLY_LINES.length)], 900);
        }
        @Override public void onElementChanged(String name) { /* 换属性不说话 */ }
        @Override public void onTripleTap() {
            /* 三击：退出（回桌面） */
            say(this, "先回桌面", 700);
            goHome();
        }
    }

    private WindowManager wm;
    private final List<Pet> pets = new ArrayList<Pet>();
    private LinearLayout menu;
    private WindowManager.LayoutParams menuLp;
    private Pet menuTarget;
    private int screenW, screenH;
    private float gyroX = 0f;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private boolean muted = false;
    private boolean aiTalk = true;
    private boolean aiBusy = false;
    private final ArrayList<String> aiCache = new ArrayList<String>();
    private long lastTick = 0L;
    /* 物理手感参数 */
    private float cfgGravity = 2600f;
    private float cfgBounce = 0.45f;
    private float cfgFriction = 0.40f;
    private float cfgThrow = 1.10f;
    private boolean cfgTopBounce = true;
    private boolean cfgMultiCollide = true;
    private boolean cfgLowSpec = false;
    private float cfgMove = 1.0f;        /* 移动速度倍率 */
    private long cfgTalkGap = 30000L;    /* 冒泡间隔 */
    /* 活动范围（像素），默认整屏 */
    private int bL = 0, bT = 0, bR = 0, bB = 0;
    private View rangeOverlay = null;
    private final java.util.List<float[]> poly = new java.util.ArrayList<float[]>();
    private long cfgReadAt = 0L;
    private long frameCount = 0L;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            long now = System.currentTimeMillis();
            float dt = lastTick == 0 ? 0.033f : Math.min(0.06f, (now - lastTick) / 1000f);
            lastTick = now;
            if (now - cfgReadAt > 1200L) readPhysicsPrefs();
            frameCount++;
            boolean skip = cfgLowSpec && (frameCount % 2 == 1);
            if (!skip) {
                for (int i = 0; i < pets.size(); i++) step(pets.get(i), now, dt);
                if (cfgMultiCollide && !cfgLowSpec) resolveCollisions(now);
            }
            h.postDelayed(this, 33L);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("slimepet", MODE_PRIVATE);
        muted = sp.getBoolean("muted", false);
        aiTalk = sp.getBoolean("ai_talk", true);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels; screenH = dm.heightPixels;
        createChannel();
        startForeground(ID_PET, buildNotification());
        int n = Math.max(1, sp.getInt("count", 1));
        for (int i = 0; i < n; i++) addPet(i, n);
        readPhysicsPrefs();
        registerGyro();
        h.postDelayed(tick, 33L);
    }

    @Override public int onStartCommand(Intent intent, int f, int s) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (intent != null && ACTION_SET_COUNT.equals(intent.getAction())) {
            setPetCount(Math.max(1, sp.getInt("count", 1)));
        }
        return START_STICKY;
    }

    /** 把数量直接改成 target（多退少补） */
    private void setPetCount(int target) {
        if (target < 1) target = 1;
        while (pets.size() > target) {
            Pet last = pets.remove(pets.size() - 1);
            try { if (last.bubble != null) wm.removeView(last.bubble); } catch (Exception ignored) {}
            try { if (last.view != null) wm.removeView(last.view); } catch (Exception ignored) {}
        }
        while (pets.size() < target) {
            int n = pets.size();
            addPet(n, n + 1);
        }
        sp.edit().putInt("count", pets.size()).apply();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        unregisterGyro();
        for (Pet p : pets) {
            try { if (p.bubble != null) wm.removeView(p.bubble); } catch (Exception ignored) {}
            try { if (p.view != null) wm.removeView(p.view); } catch (Exception ignored) {}
        }
        pets.clear();
        try { if (menu != null) wm.removeView(menu); } catch (Exception ignored) {}
        super.onDestroy();
    }

    /* ================= 添加 / 移除 ================= */
    private int sizePx() {
        int s = sp.getInt("size", 1);
        return dp(SIZES_DP[Math.max(0, Math.min(2, s))]);
    }

    private void addPet(int index, int total) {
        Pet p = new Pet();
        p.view = new SlimeView(this);
        p.view.setCallback(p);
        int s = sizePx();
        p.lp = new WindowManager.LayoutParams(s, s,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.lp.gravity = Gravity.TOP | Gravity.START;

        float slot = (total <= 1) ? 0.5f : (index + 1f) / (total + 1f);
        if (bR <= 0) bR = screenW;
        if (bB <= 0) bB = screenH;
        p.px = Math.max(bL, Math.min(bR - s, screenW * slot - s / 2f));
        p.py = bB - s;
        p.lp.x = Math.round(p.px);
        p.lp.y = Math.round(p.py);
        p.nextWalkAt = System.currentTimeMillis() + 3000L + rnd.nextInt(3000);
        try { wm.addView(p.view, p.lp); pets.add(p); } catch (Exception ignored) {}
    }

    private void addOnePet() {
        int n = pets.size();
        addPet(n, n + 1);
        sp.edit().putInt("count", pets.size()).apply();
    }

    private void removeOnePet() {
        if (pets.size() <= 1) { say(pets.get(0), "至少留一只", 1600); return; }
        Pet p = pets.remove(pets.size() - 1);
        try { if (p.bubble != null) wm.removeView(p.bubble); } catch (Exception ignored) {}
        try { if (p.view != null) wm.removeView(p.view); } catch (Exception ignored) {}
        sp.edit().putInt("count", pets.size()).apply();
    }

    private void pushWindow(Pet p) {
        if (p == null || p.view == null || p.lp == null) return;
        p.lp.x = Math.round(p.px);
        p.lp.y = Math.round(p.py);
        try { wm.updateViewLayout(p.view, p.lp); } catch (Exception ignored) {}
        positionBubbleNow(p);
    }

    private void clamp(Pet p) {
        int s = sizePx();
        if (p.px < bL) p.px = bL;
        if (p.px > bR - s) p.px = bR - s;
        if (p.py < bT) p.py = bT;
        if (p.py > bB - s) p.py = bB - s;
    }

    /* ================= 物理 ================= */
    private void step(Pet p, long now, float dt) {
        if (p.view == null || p.dragging) return;
        int s = sizePx();
        float floor = bB - s;

        if (p.nextColorAt == 0L) p.nextColorAt = now + 60000L;
        if (p.nextTalkAt == 0L) p.nextTalkAt = now + cfgTalkGap;
        if (now > p.nextColorAt) {
            int next = p.view.elementIndex();
            do { next = rnd.nextInt(7); } while (next == p.view.elementIndex());
            p.view.setElementIndex(next);
            p.nextColorAt = now + 60000L;
        }
        if (now > p.nextTalkAt && !muted && !p.view.isSleeping()) {
            if (aiTalk && !aiCache.isEmpty()) {
                say(p, aiCache.remove(0), 3400);
                p.nextTalkAt = now + (long) (cfgTalkGap * (0.7f + rnd.nextFloat() * 0.6f));
            } else if (aiTalk) {
                askAi(p, false);
                p.nextTalkAt = now + (long) (cfgTalkGap * 1.4f);
            }
            else {
                String[] mine = FORM_LINES[Math.max(0, Math.min(6, p.view.elementIndex()))];
                say(p, (rnd.nextFloat() < 0.5f) ? mine[rnd.nextInt(mine.length)] : QUIET[rnd.nextInt(QUIET.length)], 2800);
                p.nextTalkAt = now + (long) (cfgTalkGap * (0.6f + rnd.nextFloat() * 0.8f));
            }
        }

        boolean asleep = p.view.isSleeping();

        if (p.wall != 0) {
            if (asleep) { p.view.setClimbing(false); pushWindow(p); return; }
            if (p.wall == 1 || p.wall == 2) {
                p.px = (p.wall == 1) ? bL : bR - s;
                p.view.setClimbing(true);
                if (p.wallDir < 0) {
                    p.py -= 62f * cfgMove * dt;
                    if (p.py <= bT) { p.py = bT; p.wall = 3; p.view.setPose(3); p.wallDir = (p.px < screenW / 2f) ? 1 : -1; }
                } else {
                    p.py += 46f * cfgMove * dt;
                    if (p.py >= floor) { p.wall = 0; p.view.setPose(0); p.view.setClimbing(false); p.mode = 0; p.py = floor; p.nextWalkAt = now + 6000L; p.climbCool = now + 9000L; }
                }
                p.view.setGaze(0f, p.wallDir < 0 ? -0.8f : 0.8f);
            } else {
                p.py = bT;
                p.view.setClimbing(true);
                if (now > p.ceilingPause) {
                    p.px += p.wallDir * 40f * cfgMove * dt;
                    if (rnd.nextFloat() < 0.010f) p.ceilingPause = now + 3000L + rnd.nextInt(5000);
                }
                if (p.px <= bL) { p.px = bL; p.wall = 1; p.wallDir = 1; p.view.setPose(1); p.ceilingPause = now + 1200L; }
                if (p.px >= bR - s) { p.px = bR - s; p.wall = 2; p.wallDir = 1; p.view.setPose(2); p.ceilingPause = now + 1200L; }
                p.view.setGaze(p.wallDir > 0 ? 0.7f : -0.7f, 0f);
            }
            pushWindow(p);
            return;
        }

        if (p.mode == 1 && !asleep) {
            p.px += p.walkDir * 46f * cfgMove * dt;
            p.hopPhase += dt / 0.95f;
            if (p.hopPhase >= 1f) p.hopPhase -= 1f;
            float hop;
            if (p.hopPhase < 0.18f) { hop = 0f; p.view.hopStart(); }
            else if (p.hopPhase < 0.80f) { float u = (p.hopPhase - 0.18f) / 0.62f; hop = 4f * s * 0.16f * u * (1f - u); }
            else { hop = 0f; p.view.land(); }
            p.py = floor - hop;
            p.view.setGaze(p.walkDir * 0.7f, 0.15f);
            if (now > p.nextWalkAt) { p.mode = 0; p.hopPhase = 0f; p.py = floor; p.nextWalkAt = now + 2000L + rnd.nextInt(4000); }
            if (p.px <= bL) { p.px = bL; p.walkDir = 1; if (now > p.climbCool) startClimb(p, 1, now); }
            if (p.px >= bR - s) { p.px = bR - s; p.walkDir = -1; if (now > p.climbCool) startClimb(p, 2, now); }
            pushWindow(p);
            return;
        }

        if (!asleep && p.py >= floor - 1f && now > p.nextWalkAt) {
            p.mode = 1;
            p.walkDir = rnd.nextBoolean() ? 1 : -1;
            p.view.hopStart();
            p.nextWalkAt = now + 1400L + rnd.nextInt(2600);
        }

        if (p.py < floor - 1f) {
            p.vy += cfgGravity * dt;
            p.vx += gyroX * 260f * dt;
            p.px += p.vx * dt;
            p.py += p.vy * dt;
            if (p.py >= floor) {
                p.py = floor;
                if (p.vy > 220f) { p.vy = -p.vy * cfgBounce; p.view.land(); if (!muted && rnd.nextFloat() < 0.3f) say(p, "哎哟", 900); }
                else { p.vy = 0f; p.mode = 0; p.nextWalkAt = now + 1500L; }
            }
        } else {
            if (Math.abs(gyroX) > 0.22f) { p.px += gyroX * 95f * dt; p.view.setGaze(gyroX > 0 ? 0.8f : -0.8f, 0.2f); }
            /* 地面摩擦 */
            p.vx *= Math.max(0f, 1f - cfgFriction * dt * 3f);
            if (Math.abs(p.vx) < 4f) p.vx = 0f;
            p.px += p.vx * dt;
            p.py = floor; p.vy = 0f;
        }

        /* 只有速度接近零时才会粘上墙；撞得快的先弹开 */
        float spd = (float) Math.sqrt(p.vx * p.vx + p.vy * p.vy);
        boolean canStick = spd < 160f;
        if (p.px <= bL) {
            p.px = bL;
            if (canStick && now > p.climbCool) startClimb(p, 1, now);
            else { p.vx = Math.abs(p.vx) * cfgBounce; if (p.vx < 40f) p.vx = 0f; }
        }
        if (p.px >= bR - s) {
            p.px = bR - s;
            if (canStick && now > p.climbCool) startClimb(p, 2, now);
            else { p.vx = -Math.abs(p.vx) * cfgBounce; if (p.vx > -40f) p.vx = 0f; }
        }
        if (p.py < bT && cfgTopBounce) { p.py = bT; p.vy = Math.abs(p.vy) * cfgBounce; }
        confine(p);
        pushWindow(p);
    }

    /** 史莱姆之间的碰撞：只按身体（半径 0.8R）算，且不允许重合 */
    private void resolveCollisions(long now) {
        int n = pets.size();
        if (n < 2) return;
        int s = sizePx();
        float R = s * 0.33f;
        float rb = R * 0.80f;                    /* 身体半径 */
        float cx = s * 0.5f, cy = s * 0.60f;     /* 身体中心在窗口里的位置 */
        float minD = rb * 2f;

        /* 两轮求解：第一轮分离位置，第二轮处理被屏幕边夹回来的情况 */
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < n; i++) {
                Pet p1 = pets.get(i);
                if (p1.view == null) continue;
                for (int j = i + 1; j < n; j++) {
                    Pet p2 = pets.get(j);
                    if (p2.view == null) continue;

                    float ax = p1.px + cx, ay = p1.py + cy;
                    float bx = p2.px + cx, by = p2.py + cy;
                    float dx = bx - ax, dy = by - ay;
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d < 0.0001f) { dx = 1f; dy = 0.01f; d = (float) Math.sqrt(dx * dx + dy * dy); }
                    if (d >= minD) continue;

                    float nx = dx / d, ny = dy / d;
                    float overlap = minD - d;

                    /* 被手按住、或正贴墙的那只当作不可推动 */
                    float wa = (p1.dragging || p1.wall != 0) ? 0f : 1f;
                    float wb = (p2.dragging || p2.wall != 0) ? 0f : 1f;
                    float wsum = wa + wb;
                    if (wsum <= 0f) continue;         /* 两个都不能动，跳过 */

                    /* 位置：一次推到位，保证不重合 */
                    p1.px -= nx * overlap * (wa / wsum);
                    p1.py -= ny * overlap * (wa / wsum);
                    p2.px += nx * overlap * (wb / wsum);
                    p2.py += ny * overlap * (wb / wsum);

                    if (pass == 0) {
                        /* 速度：等质量弹性碰撞，动量守恒 */
                        float rvx = p2.vx - p1.vx;
                        float rvy = p2.vy - p1.vy;
                        float vn = rvx * nx + rvy * ny;
                        if (vn < 0f) {
                            float e = 0.90f;
                            float ma = wa > 0f ? 1f : 1e6f;
                            float mb = wb > 0f ? 1f : 1e6f;
                            float jImp = -(1f + e) * vn / (1f / ma + 1f / mb);
                            p1.vx -= (jImp / ma) * nx; p1.vy -= (jImp / ma) * ny;
                            p2.vx += (jImp / mb) * nx; p2.vy += (jImp / mb) * ny;
                            if (wa > 0f) p1.mode = 2;
                            if (wb > 0f) p2.mode = 2;

                            p1.view.setGaze(nx * 0.9f, ny * 0.9f);
                            p2.view.setGaze(-nx * 0.9f, -ny * 0.9f);

                            if (now - p1.lastBump > 700L && -vn > 120f) {
                                p1.lastBump = now;
                                p1.view.land(); p2.view.land();
                                if (!muted && rnd.nextFloat() < 0.30f) {
                                    say(rnd.nextBoolean() ? p1 : p2, BUMP_LINES[rnd.nextInt(BUMP_LINES.length)], 1500);
                                }
                            }
                        }
                    }

                    clamp(p1); clamp(p2);
                    pushWindow(p1); pushWindow(p2);
                }
            }
        }
    }

    private void readPhysicsPrefs() {
        int g = sp.getInt("gravity", 2600);
        cfgGravity = Math.max(300f, Math.min(4000f, g));
        cfgBounce = Math.max(0, Math.min(100, sp.getInt("bounce", 45))) / 100f;
        cfgFriction = Math.max(0, Math.min(100, sp.getInt("friction", 40))) / 100f;
        cfgThrow = Math.max(50, Math.min(200, sp.getInt("throw", 110))) / 100f;
        cfgTopBounce = sp.getBoolean("top_bounce", true);
        cfgMultiCollide = sp.getBoolean("multi_collide", true);
        cfgLowSpec = sp.getBoolean("low_spec", false);
        cfgMove = Math.max(20, Math.min(200, sp.getInt("move_speed", 100))) / 100f;
        cfgTalkGap = Math.max(5, Math.min(300, sp.getInt("talk_gap", 30))) * 1000L;
        bL = Math.max(0, sp.getInt("bound_l", 0));
        bT = Math.max(0, sp.getInt("bound_t", 0));
        bR = sp.getInt("bound_r", 0); if (bR <= 0) bR = screenW;
        bB = sp.getInt("bound_b", 0); if (bB <= 0) bB = screenH;
        poly.clear();
        String reg = sp.getString("region", "");
        if (reg.length() > 0) {
            for (String seg : reg.split(";")) {
                String[] xy = seg.split(",");
                if (xy.length == 2) {
                    try { poly.add(new float[]{Float.parseFloat(xy[0]), Float.parseFloat(xy[1])}); } catch (Exception ignored) {}
                }
            }
        }
        cfgReadAt = System.currentTimeMillis();
    }

    /** 铺一层遮罩，让用户手绘活动范围 */
    private void startDrawRange() {
        if (rangeOverlay != null) return;
        final DrawRegionView dv = new DrawRegionView(this);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        dv.setDone(new DrawRegionView.Done() {
            @Override public void onRegion(java.util.List<android.graphics.PointF> pts) {
                StringBuilder sb = new StringBuilder();
                float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -1, maxY = -1;
                for (android.graphics.PointF q : pts) {
                    if (sb.length() > 0) sb.append(';');
                    sb.append(Math.round(q.x)).append(',').append(Math.round(q.y));
                    minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
                    minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
                }
                sp.edit().putString("region", sb.toString())
                        .putInt("bound_l", (int) minX).putInt("bound_t", (int) minY)
                        .putInt("bound_r", (int) maxX).putInt("bound_b", (int) maxY).apply();
                readPhysicsPrefs();
                for (Pet p : pets) { confine(p); clamp(p); pushWindow(p); }
                closeRangeOverlay();
                say(pets.isEmpty() ? null : pets.get(0), "范围画好了", 1600);
            }
            @Override public void onCancel() {
                closeRangeOverlay();
                say(pets.isEmpty() ? null : pets.get(0), "取消了", 1200);
            }
        });
        try { wm.addView(dv, lp); rangeOverlay = dv; } catch (Exception ignored) {}
    }

    /** 矩形范围：拖两个角 */
    /** 三连击关机：需要 Shizuku 以 shell 身份执行 */
    private void shutdownDevice() {
        if (!ShizukuShell.canRun()) {
            say(pets.isEmpty() ? null : pets.get(0), "要先用 Shizuku 授权才能关机", 3200);
            ShizukuShell.requestPermission();
            return;
        }
        say(pets.isEmpty() ? null : pets.get(0), "关机…", 1200);
        new Thread(new Runnable() {
            @Override public void run() {
                ShizukuShell.exec("reboot -p");
                try { Thread.sleep(1500); } catch (Exception ignored) {}
                ShizukuShell.exec("svc power shutdown");
            }
        }).start();
    }

    private void startDrawRect() {
        if (rangeOverlay != null) return;
        final DrawRectView dv = new DrawRectView(this);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        dv.setDone(new DrawRectView.Done() {
            @Override public void onRect(android.graphics.Rect r) {
                sp.edit().putInt("bound_l", r.left).putInt("bound_t", r.top)
                        .putInt("bound_r", r.right).putInt("bound_b", r.bottom)
                        .putString("region", "").apply();     /* 矩形模式：清掉多边形 */
                readPhysicsPrefs();
                for (Pet p : pets) { clamp(p); pushWindow(p); }
                closeRangeOverlay();
                say(pets.isEmpty() ? null : pets.get(0), "矩形范围好了", 1600);
            }
            @Override public void onCancel() {
                closeRangeOverlay();
                say(pets.isEmpty() ? null : pets.get(0), "取消了", 1200);
            }
        });
        try { wm.addView(dv, lp); rangeOverlay = dv; } catch (Exception ignored) {}
    }

    private void closeRangeOverlay() {
        if (rangeOverlay != null) {
            try { wm.removeView(rangeOverlay); } catch (Exception ignored) {}
            rangeOverlay = null;
        }
    }

    private void resetRange() {
        sp.edit().putInt("bound_l", 0).putInt("bound_t", 0).putInt("bound_r", 0).putInt("bound_b", 0)
                .putString("region", "").apply();
        readPhysicsPrefs();
        for (Pet p : pets) { clamp(p); pushWindow(p); }
        say(pets.isEmpty() ? null : pets.get(0), "回到全屏", 1400);
    }

    private boolean insidePoly(float x, float y) {
        int n = poly.size();
        if (n < 3) return true;
        boolean in = false;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float xi = poly.get(i)[0], yi = poly.get(i)[1];
            float xj = poly.get(j)[0], yj = poly.get(j)[1];
            if (((yi > y) != (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) in = !in;
        }
        return in;
    }

    /** 跑出画的区域就拉回来，速度沿法线反弹 */
    private void confine(Pet p) {
        int n = poly.size();
        if (n < 3) return;
        int s = sizePx();
        float cx = p.px + s * 0.5f, cy = p.py + s * 0.60f;
        float rad = s * 0.33f * 0.8f;
        if (insidePoly(cx, cy)) return;

        /* 找最近的边界点 */
        float bestX = 0, bestY = 0, bestD = Float.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            float ax = poly.get(i)[0], ay = poly.get(i)[1];
            float bx = poly.get((i + 1) % n)[0], by = poly.get((i + 1) % n)[1];
            float dx = bx - ax, dy = by - ay;
            float len2 = dx * dx + dy * dy;
            float t = len2 <= 0 ? 0 : ((cx - ax) * dx + (cy - ay) * dy) / len2;
            t = Math.max(0, Math.min(1, t));
            float qx = ax + dx * t, qy = ay + dy * t;
            float d = (cx - qx) * (cx - qx) + (cy - qy) * (cy - qy);
            if (d < bestD) { bestD = d; bestX = qx; bestY = qy; }
        }

        /* 内部方向 = 指向多边形重心 */
        float gx = 0, gy = 0;
        for (int i = 0; i < n; i++) { gx += poly.get(i)[0]; gy += poly.get(i)[1]; }
        gx /= n; gy /= n;
        float nx = gx - bestX, ny = gy - bestY;
        float nl = (float) Math.sqrt(nx * nx + ny * ny);
        if (nl < 0.001f) { nx = 0; ny = -1; nl = 1; }
        nx /= nl; ny /= nl;

        /* 把中心推回边界内侧 rad 处 */
        p.px = bestX + nx * (rad + 3f) - s * 0.5f;
        p.py = bestY + ny * (rad + 3f) - s * 0.60f;
        clamp(p);

        /* 切向不变，法向反弹 */
        float vn = p.vx * nx + p.vy * ny;
        if (vn < 0f) {
            p.vx -= (1f + cfgBounce) * vn * nx;
            p.vy -= (1f + cfgBounce) * vn * ny;
        }
        p.mode = 2;
        pushWindow(p);
    }

    private void startClimb(Pet p, int which, long now) {
        if (p.view == null) return;
        p.view.setClimbing(true);
        p.wall = which; p.wallSince = now; p.wallDir = -1;
        p.vx = 0f; p.vy = 0f;
        p.view.setPose(which);
        if (!muted && rnd.nextFloat() < 0.35f) say(p, "我爬上去咯", 1200);
    }

    /* ================= 陀螺仪 ================= */
    private void registerGyro() {
        try {
            SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor a = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (a != null) sm.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME);
        } catch (Exception ignored) {}
    }

    private void unregisterGyro() {
        try { ((SensorManager) getSystemService(SENSOR_SERVICE)).unregisterListener(this); } catch (Exception ignored) {}
    }

    @Override public void onSensorChanged(SensorEvent e) {
        if (e == null || e.values == null || e.values.length < 2) return;
        gyroX = -e.values[0] / 9.8f;
        if (gyroX > 1f) gyroX = 1f;
        if (gyroX < -1f) gyroX = -1f;
    }

    @Override public void onAccuracyChanged(Sensor s, int a) {}

    /* ================= 菜单 ================= */
    private void showMenu(final Pet target) {
        dismissMenu();
        menuTarget = target;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE6151A24);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0x33FFFFFF);
        box.setBackground(bg);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));

        addItem(box, "换元素（下一个）", new Runnable() { @Override public void run() { menuTarget.view.setElementIndex(menuTarget.view.elementIndex() + 1); dismissMenu(); } });
        addItem(box, "大一点", new Runnable() { @Override public void run() { resize(1); } });
        addItem(box, "小一点", new Runnable() { @Override public void run() { resize(-1); } });
        addItem(box, menuTarget.view.isSleeping() ? "叫醒她" : "让她睡", new Runnable() {
            @Override public void run() { menuTarget.view.setSleeping(!menuTarget.view.isSleeping()); dismissMenu(); }
        });
        addItem(box, muted ? "开口说话" : "闭嘴", new Runnable() {
            @Override public void run() { muted = !muted; sp.edit().putBoolean("muted", muted).apply(); dismissMenu(); }
        });
        addItem(box, aiTalk ? "说话来源：AI" : "说话来源：本地", new Runnable() {
            @Override public void run() { aiTalk = !aiTalk; sp.edit().putBoolean("ai_talk", aiTalk).apply(); say(menuTarget, aiTalk ? "以后我现编" : "以后说存好的", 1600); dismissMenu(); }
        });
        addItem(box, "说句话（AI）", new Runnable() { @Override public void run() { Pet t = menuTarget; dismissMenu(); askAi(t, true); } });
        addItem(box, "画矩形范围", new Runnable() { @Override public void run() { dismissMenu(); startDrawRect(); } });
        addItem(box, "画自由范围", new Runnable() { @Override public void run() { dismissMenu(); startDrawRange(); } });
        addItem(box, "范围恢复全屏", new Runnable() { @Override public void run() { dismissMenu(); resetRange(); } });
        addItem(box, "再放一只", new Runnable() { @Override public void run() { dismissMenu(); addOnePet(); } });
        addItem(box, "收走一只", new Runnable() { @Override public void run() { dismissMenu(); removeOnePet(); } });
        addItem(box, "自动睡觉：" + (menuTarget.view.autoSleep ? "开" : "关"), new Runnable() {
            @Override public void run() { menuTarget.view.autoSleep = !menuTarget.view.autoSleep; sp.edit().putBoolean("auto_sleep", menuTarget.view.autoSleep).apply(); say(menuTarget, menuTarget.view.autoSleep ? "会自己睡" : "不自己睡了", 1400); dismissMenu(); }
        });
        addItem(box, "调试信息", new Runnable() { @Override public void run() { say(menuTarget, menuTarget.view.debugLine(), 5000); dismissMenu(); } });
        addItem(box, "关机（需 Shizuku）", new Runnable() { @Override public void run() { dismissMenu(); shutdownDevice(); } });
        addItem(box, "收起来", new Runnable() { @Override public void run() { stopSelf(); } });
        addItem(box, "关闭菜单", new Runnable() { @Override public void run() { dismissMenu(); } });

        menuLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        menuLp.gravity = Gravity.TOP | Gravity.START;
        int x = Math.round(target.px) + sizePx() + dp(6);
        if (x > screenW - dp(190)) x = Math.max(dp(4), Math.round(target.px) - dp(190));
        int y = Math.round(target.py) - dp(20);
        if (y < dp(60)) y = dp(60);
        menuLp.x = x; menuLp.y = y;
        menu = box;
        try { wm.addView(menu, menuLp); } catch (Exception e) { menu = null; }
    }

    private void addItem(LinearLayout box, String text, final Runnable action) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13f);
        tv.setTextColor(0xFFE8EDF6);
        tv.setPadding(dp(12), dp(9), dp(14), dp(9));
        tv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { action.run(); } });
        box.addView(tv);
    }

    private void dismissMenu() {
        if (menu != null) { try { wm.removeView(menu); } catch (Exception ignored) {} menu = null; }
    }

    private void resize(int delta) {
        int cur = Math.min(2, Math.max(0, sp.getInt("size", 1)));
        int next = Math.min(2, Math.max(0, cur + delta));
        sp.edit().putInt("size", next).apply();
        int s = dp(SIZES_DP[next]);
        for (Pet p : pets) {
            p.lp.width = s; p.lp.height = s;
            float floor = screenH - s - dp(8);
            if (p.py > floor) p.py = floor;
            clamp(p);
            pushWindow(p);
        }
        dismissMenu();
    }

    /* ================= 气泡（每只一个） ================= */
    private void ensureBubble(Pet p) {
        if (p.bubble != null) return;
        TextView tv = new TextView(this);
        tv.setTextSize(13f);
        tv.setTextColor(0xFF2B2B3A);
        tv.setMaxWidth(dp(230));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0xF7FFFFFF);
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), 0x33000000);
        tv.setBackground(gd);
        tv.setPadding(dp(12), dp(8), dp(12), dp(8));
        tv.setVisibility(View.GONE);
        p.bubLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.bubLp.gravity = Gravity.TOP | Gravity.START;
        try { wm.addView(tv, p.bubLp); p.bubble = tv; } catch (Exception ignored) { p.bubble = null; }
    }

    private void say(final Pet p, String text, long ms) {
        if (muted || p == null) return;
        ensureBubble(p);
        if (p.bubble == null) return;
        p.bubble.setText(text);
        p.bubble.setVisibility(View.GONE);
        p.bubble.post(new Runnable() { @Override public void run() { positionBubbleNow(p); if (p.bubble != null) p.bubble.setVisibility(View.VISIBLE); } });
        final TextView b = p.bubble;
        h.postDelayed(new Runnable() { @Override public void run() { if (b != null) b.setVisibility(View.GONE); } }, ms);
    }

    private void positionBubbleNow(Pet p) {
        if (p == null || p.bubble == null || p.bubLp == null || p.lp == null) return;
        if (p.bubble.getVisibility() != View.VISIBLE) return;
        int bw = p.bubble.getWidth(), bh = p.bubble.getHeight();
        if (bw <= 0 || bh <= 0) return;
        int x = p.lp.x + p.lp.width / 2 - bw / 2;
        if (x < dp(2)) x = dp(2);
        if (x > screenW - bw - dp(2)) x = screenW - bw - dp(2);
        int y;
        if (p.wall == 3) y = p.lp.y + Math.round(p.lp.height * 0.50f) + dp(2);
        else y = p.lp.y + Math.round(p.lp.height * 0.27f) - bh - dp(2);
        if (y < dp(2)) y = p.lp.y + Math.round(p.lp.height * 0.50f);
        p.bubLp.x = x; p.bubLp.y = y;
        try { wm.updateViewLayout(p.bubble, p.bubLp); } catch (Exception ignored) {}
    }

    /* ================= AI 台词 ================= */
    private void askAi(final Pet p, final boolean onDemand) {
        if (aiBusy || p == null) return;
        final String key = sp.getString("api_key", "").trim();
        if (key.length() < 10) { if (onDemand) say(p, "先在 App 里填 API Key", 2600); return; }
        aiBusy = true;
        final String form = p.view.elementName();
        final String[] fallback = FORM_LINES[Math.max(0, Math.min(6, p.view.elementIndex()))];
        new Thread(new Runnable() {
            @Override public void run() {
                String reply = null;
                try {
                    String sys = "你是原神里的" + form + "史莱姆，名字叫琳，安静、透明，住在手机屏幕边上。"
                            + "请给我 6 句不同的中文短句，每句 20 字以内，用 || 分隔，不要编号，不要解释。"
                            + "每一句都要有一点哲理和疏离感，像自言自语，避免网络流行语和撒娇。";
                    String body = "{\"model\":\"deepseek-chat\",\"max_tokens\":120,\"temperature\":1.25,"
                            + "\"messages\":[{\"role\":\"system\",\"content\":\"" + esc(sys) + "\"},"
                            + "{\"role\":\"user\",\"content\":\"此刻你说一句话。\"}]}";
                    HttpURLConnection conn = (HttpURLConnection) new URL("https://api.deepseek.com/chat/completions").openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(15000);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Authorization", "Bearer " + key);
                    conn.setDoOutput(true);
                    OutputStream os = conn.getOutputStream();
                    os.write(body.getBytes("UTF-8"));
                    os.flush(); os.close();
                    int code = conn.getResponseCode();
                    BufferedReader br = new BufferedReader(new InputStreamReader(
                            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder(); String ln;
                    while ((ln = br.readLine()) != null) sb.append(ln);
                    br.close();
                    String json = sb.toString();
                    if (code >= 200 && code < 300) {
                        int i = json.indexOf("\"content\":");
                        if (i > 0) {
                            int q1 = json.indexOf('"', i + 10);
                            StringBuilder val = new StringBuilder();
                            if (q1 > 0) {
                                for (int k = q1 + 1; k < json.length(); k++) {
                                    char ch = json.charAt(k);
                                    if (ch == '\\') { k++; if (k < json.length()) val.append(json.charAt(k)); continue; }
                                    if (ch == '"') break;
                                    val.append(ch);
                                }
                            }
                            String raw = val.toString().trim();
                            String[] parts = raw.split("\\|\\||\\n|；|;");
                            for (String pt : parts) {
                                String one = pt.trim().replace("\"", "").replace("。", "").trim();
                                if (one.length() >= 4 && one.length() <= 24) aiCache.add(one);
                            }
                            if (!aiCache.isEmpty()) reply = aiCache.remove(0);
                        }
                    }
                } catch (Exception ignored) {}
                final String r = reply;
                h.post(new Runnable() {
                    @Override public void run() {
                        aiBusy = false;
                        if (!muted) {
                            if (r != null && r.length() > 0) say(p, r, 3600);
                            else if (onDemand) say(p, fallback[rnd.nextInt(fallback.length)], 2600);
                        }
                    }
                });
            }
        }).start();
    }

    private static String esc(String sIn) {
        return sIn.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void goHome() {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {}
    }

    /* ================= 通知 ================= */
    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CH_PET, "桌宠常驻", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false);
        nm.createNotificationChannel(c);
    }

    private Notification buildNotification() {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent si = new Intent(this, PetService.class);
        si.setAction(ACTION_STOP);
        PendingIntent spi = PendingIntent.getService(this, 1, si,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CH_PET)
                .setSmallIcon(R.drawable.ic_noti)
                .setContentTitle("琳 正在陪你")
                .setContentText("单击换形态 · 双击睡/醒 · 三击回桌面 · 长按菜单")
                .setContentIntent(pi)
                .setOngoing(true);
        b.addAction(new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "收起来", spi).build());
        return b.build();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
